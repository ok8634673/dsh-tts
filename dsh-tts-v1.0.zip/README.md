# TTS 加速器 — 使用文档

> 基于 **GPT-SoVITS** 的中文/日文语音合成。当前主力后端是局域网内的 **neko api**（GPT-SoVITS API v3）。
>
> **给外部调用方**：本文档只讲「怎么调」。最省事的方式是**直接 HTTP 调用 neko api**（见 §3），不需要依赖本目录的 Python 脚本。
>
> 文档版本 v3.0 | 最后更新 2026-10-15

---

## 目录

1. [30 秒上手](#1-30-秒上手)
2. [可用音色](#2-可用音色)
3. [⭐ neko api 直连（推荐给外部调用方）](#3--neko-api-直连推荐给外部调用方)
4. [命令行脚本](#4-命令行脚本)
5. [输出产物](#5-输出产物)
6. [服务器拓扑](#6-服务器拓扑)
7. [常见坑 / 排障](#7-常见坑--排障)
8. [环境要求](#8-环境要求)
9. [文件清单](#9-文件清单)

---

## 1. 30 秒上手

### 方式 A：命令行（本机使用）

```bash
python "H:\WorkBuddy\Obsidian\04-WorkBuddy\软件工具\TTS加速器\tts_auto.py" 春原瞬 "せんせい！今天也要加油哦～"
```

执行后 stdout 会打印音频路径：

```
[AUDIO_FILE]H:\WorkBuddy\generated_audio\春原瞬-せんせい！今天也要加油哦～-20261015_094600.wav
```

### 方式 B：HTTP 直连（外部 harness / 其他语言）— 已验证 ✅

```python
import urllib.parse, urllib.request

q = urllib.parse.urlencode({
    "text": "せんせい！今天也要加油哦～",
    "text_lang": "auto",
    "ref_audio_path": "api_neko/voices/shun-请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！.wav",
    "prompt_text": "请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！",
    "prompt_lang": "all_zh",
    "text_split_method": "cut5",
    "speed_factor": 1.0,
})
raw = urllib.request.urlopen("http://192.168.31.8:9881/api/v2/tts?" + q, timeout=300).read()
open("out.wav", "wb").write(raw)      # 标准单文件 WAV：32kHz / 16bit / 单声道
```

只需标准库，**不需要装任何依赖**。换音色时记得先切权重（§3.3）。

> ⚠️ **Windows 下不要用 `curl --data-urlencode` 传中文参数** —— Git Bash / cmd 会按 **GBK** 编码发出，服务端返回 `400 xxx.wav not exists`（实测踩过）。Linux / macOS 下 curl 正常，写法见 §3.6。

详见 §3。

---

## 2. 可用音色

### ⭐ 默认音色（2026-10-15 老师指定）

**用 `shun`（gsv 后端 / 显卡加速）。不要用 `*-onnx` 系列** —— 那是 `backend=genie` 的 CPU 推理，声线会飘。

```bash
python say.py "要朗读的文本" --play        # 默认 shun
python say.py --list                       # 看全部音色 + GPU/CPU 标注
```

### ⚠️ 前提

目前**旧服务器（9880 端口那批）已全部下线**，只有 neko api 可用。neko api 上**只注册了 4 个音色**，其余角色调不了。

| 调用名（CLI） | voice_id | 底子 | 参考音频语种 | 说明 |
|---|---|---|---|---|
| `春原瞬` | `shun` | **国语底** ⭐ 默认 | `all_zh` | 中文发音更准，日常首选 |
| `春原瞬jp` | `shun-jp` | **日语底** | `all_ja` | 日语味更纯 |
| `春原心奈` | `kokona` | 国语底 | `all_zh` | |
| `丹花伊吹` | `ibuki` | 日语底 | `all_ja` | |
| `春原瞬zh` | — | —— | —— | **别名**，等同 `春原瞬`（兼容旧调用） |

> **不支持**：可莉 / 瑶瑶 / 纳西妲 / 小猫 —— 这些角色在 neko 上没有注册参考音频，请求会返回错误 `该角色在 neko 上未注册参考音频`。
>
> 服务端另有 `*-onnx` 音色（`backend=genie`，**CPU 推理，声线较差，不要用**）与 `init`（v3 预训练），**不要使用**。

### 权重对照（neko 服务端）

| voice_id | GPT 权重 | SoVITS 权重 |
|---|---|---|
| `shun` | `GPT_weights_v2/youshun-ZH-v2-e15.ckpt` | `SoVITS_weights_v2/youshun-ZH-v2_e8_s1104.pth` |
| `shun-jp` | `GPT_weights_v2/youshun-e10.ckpt` | `SoVITS_weights_v2/youshun_e10_s170.pth` |
| `kokona` | `GPT_weights_v2/kokona-v2-e15.ckpt` | `SoVITS_weights_v2/kokona_v2_e24_s312.pth` |
| `ibuki` | `GPT_weights_v2/YiChui-e15.ckpt` | `SoVITS_weights_v2/YiChui_e24_s408.pth` |

---

## 3. ⭐ neko api 直连（推荐给外部调用方）

neko api = **GPT-SoVITS API v3**，兼容老的 v2 接口。外部调用只需记住 **3 个接口**。

### 3.1 端点

| 用途 | 方法与路径 |
|---|---|
| **合成语音** | `GET /api/v2/tts` → 直接返回 WAV 二进制 |
| **切换权重**（换音色前必做） | `GET /api/v2/set_gpt_weights?weights_path=...`<br>`GET /api/v2/set_sovits_weights?weights_path=...` |
| 健康检查 | `GET /api/v3/health` |
| 音色列表 | `GET /api/v3/voices` / `GET /api/v3/voices/full` |

**Base URL**

```
http://192.168.31.8:9881     ⭐ 优先（P104-100 8GB，实时率 ~1.3x）
http://127.0.0.1:9881        兜底（本机 2GB，慢约 10 倍，主机不开时用）
```

### 3.2 合成参数（GET query）

| 参数 | 必填 | 说明 |
|---|:---:|---|
| `text` | ✅ | 要朗读的文本。**中/日/英可混在一句里** |
| `text_lang` | ✅ | 建议固定 `auto` —— neko 原生多语言识别，不用手动分段 |
| `ref_audio_path` | ✅ | **服务器端路径**（不是本机路径！），见 §2 各音色的参考音频 |
| `prompt_text` | ✅ | 参考音频对应的文本，必须与参考音频严格一致 |
| `prompt_lang` | ✅ | `all_zh` 或 `all_ja` |
| `text_split_method` | | 建议 `cut5`（服务端智能分句） |
| `speed_factor` | | 语速，`1.0` 正常；>1 快，<1 慢 |
| `top_k` / `top_p` / `temperature` | | 采样参数，默认 `5 / 1 / 1` |
| `parallel_infer` | | 默认 `true`（并行推理） |
| `repetition_penalty` | | 默认 `1.35` |

其余可选：`batch_size` `batch_threshold` `split_bucket` `seed` `fragment_interval` `media_type` `sample_steps` `super_sampling`。

### 3.3 🔑 关键：换音色**必须**先切权重

**v2 接口不接受 `voice_id`** —— 权重是**服务端全局状态**。只传 `ref_audio_path` 而权重没切，会出现「用国语底模型唱日语」的错乱。

正确顺序（**换音色时**）：

```
1) GET /api/v2/set_gpt_weights?weights_path=GPT_weights_v2/youshun-e10.ckpt
2) GET /api/v2/set_sovits_weights?weights_path=SoVITS_weights_v2/youshun_e10_s170.pth
3) GET /api/v2/tts?text=...&ref_audio_path=...&prompt_text=...&prompt_lang=all_ja
```

> 权重加载耗数秒，**同音色连续调用不需要重复切**。默认服务端已加载 `shun`（国语底），若只用 `春原瞬` 可跳过第 1、2 步。

### 3.4 完整 Python 示例（可直接复制）

```python
import urllib.parse, urllib.request

BASE = "http://192.168.31.8:9881"

VOICES = {
    "shun": {
        "gpt":    "GPT_weights_v2/youshun-ZH-v2-e15.ckpt",
        "sovits": "SoVITS_weights_v2/youshun-ZH-v2_e8_s1104.pth",
        "ref":    "api_neko/voices/shun-请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！.wav",
        "prompt": "请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！",
        "lang":   "all_zh",
    },
    "shun-jp": {
        "gpt":    "GPT_weights_v2/youshun-e10.ckpt",
        "sovits": "SoVITS_weights_v2/youshun_e10_s170.pth",
        "ref":    "api_neko/voices/shun-しゅ、シュンお姉さんはどこに行ったんでしょうね？.wav",
        "prompt": "しゅ、シュンお姉さんはどこに行ったんでしょうね？",
        "lang":   "all_ja",
    },
}

def switch_weights(voice_id):
    v = VOICES[voice_id]
    for ep, w in (("set_gpt_weights", v["gpt"]), ("set_sovits_weights", v["sovits"])):
        qs = urllib.parse.urlencode({"weights_path": w})
        urllib.request.urlopen(f"{BASE}/api/v2/{ep}?{qs}", timeout=90).read()

def tts(text, voice_id="shun", speed=1.0, out="out.wav"):
    v = VOICES[voice_id]
    q = urllib.parse.urlencode({
        "text": text, "text_lang": "auto",
        "ref_audio_path": v["ref"], "prompt_text": v["prompt"], "prompt_lang": v["lang"],
        "text_split_method": "cut5", "speed_factor": speed,
        "top_k": 5, "top_p": 1, "temperature": 1,
        "parallel_infer": True, "repetition_penalty": 1.35,
    })
    raw = urllib.request.urlopen(f"{BASE}/api/v2/tts?{q}", timeout=300).read()
    open(out, "wb").write(raw)      # 标准单文件 WAV，可直接播放
    return out

if __name__ == "__main__":
    switch_weights("shun")
    tts("せんせい！这是通过 HTTP 直连生成的语音哦～", "shun", 1.0, "demo.wav")
```

### 3.5 异步接口（长文本/并发场景）

`POST /api/v3/tts` 提交任务 → 轮询 → 取音频：

```
POST /api/v3/tts            {"text": "...", "voice_id": "shun"}  → {"task_id": "..."}
GET  /api/v3/tts/{task_id}                                       → {"status": "...", "progress": ...}
GET  /api/v3/tts/{task_id}/audio                                 → WAV
```

> ⚠️ v3 开启了 `return_fragment`，`/audio` 返回的可能是**多个 RIFF 块首尾相接**，普通播放器只播第一段。**建议外部调用统一走 §3.2 的 `GET /api/v2/tts`**，它返回干净的单文件 WAV，无需合并。

### 3.6 curl 示例（仅 Linux / macOS / UTF-8 终端）

```bash
curl -G "http://192.168.31.8:9881/api/v2/tts" \
  --data-urlencode "text=せんせい！今天也要加油哦～" \
  --data-urlencode "text_lang=auto" \
  --data-urlencode "ref_audio_path=api_neko/voices/shun-请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！.wav" \
  --data-urlencode "prompt_text=请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！" \
  --data-urlencode "prompt_lang=all_zh" \
  --data-urlencode "text_split_method=cut5" \
  --data-urlencode "speed_factor=1.0" \
  -o out.wav
```

> ⚠️ **Windows 上这条命令会失败**（Git Bash / cmd 以 GBK 发送中文 → 400）。Windows 请用 §3.4 的 Python 版本。
> 若必须在 Windows 用 curl，可先用 Python 生成完整 URL 再请求：
> ```python
> import urllib.parse
> print("http://192.168.31.8:9881/api/v2/tts?" + urllib.parse.urlencode({...}))
> ```
> 然后把输出的 URL 交给 `curl -o out.wav "<URL>"`。

---

## 4. 命令行脚本

### 4.1 `tts_auto.py` — 主力（推荐）

```bash
python tts_auto.py <角色名> <文本> [选项]
```

| 选项 | 说明 |
|---|---|
| `--quiet` | 精简输出 |
| `--no-play` | 不自动播放（供程序调用时用，**外部调用建议加**） |
| `--lang zh\|ja\|en\|auto` | 指定语言；默认走角色配置（neko 下为 `auto`） |
| `--speed X` | 语速覆盖，`1.0` 正常 |

自动降级链路：探针预检 → 并行 → 流式 → 串行+流式 → 重启重试。**neko 在线时直接走并行**（跳过本地 GPU 预检）。

### 4.2 `tts_reply.py` — 底层引擎

```bash
python tts_reply.py <角色名> <文本> [选项]
```

| 选项 | 说明 |
|---|---|
| `--no-play` | 不播放 |
| `--no-save` | 不保存文件（仅探活） |
| `--verbose` | 详细日志 |
| `--streaming` | 强制流式 |
| `--no-parallel` | 串行 BERT（省显存，慢 2.5x） |
| `--speed X` | 语速覆盖 |

### 4.3 `tts_mixed.py` — 中日英分段混读（**备用**）

neko 的 `text_lang=auto` 已能整句识别多语言，**正常情况不需要它**。仅在对接不支持 `auto` 的老接口时使用：

```bash
python tts_mixed.py <角色名> <混合文本> [--quiet] [--speed-ja 1.15] [--speed-zh 1.0]
```

---

## 5. 输出产物

| 项 | 说明 |
|---|---|
| 音频目录 | `H:\WorkBuddy\generated_audio\` |
| 文件名 | `{角色名}-{文本前20字}-{YYYYMMDD_HHMMSS}.wav` |
| 格式 | 32kHz / 16bit / 单声道 WAV（`tts_auto.py` 会直接播放；`--no-play` 跳过） |
| stdout 标记 | `[AUDIO_FILE]<绝对路径>` ← **程序解析这个拿路径** |
| | `[MODE]并行模式` / `[MODE]流式模式` / `[MODE]串行+流式(终极保活)` |
| 结果文件 | 同目录 `speak_result.txt`，内容 `{生成秒数}s,{实时率}x`，如 `8.47s,1.0x` |

**给脚本调用方的建议**：加 `--no-play`，然后从 stdout 抓 `[AUDIO_FILE]` 前缀那一行。

> `speak_log.txt`（详细日志）**只在直接运行 `tts_reply.py` 时写入**；走 `tts_auto.py` 时日志只在 stdout，结果落 `speak_result.txt`。

---

## 6. 服务器拓扑

| 地址 | 硬件 | 实时率 | 角色 |
|---|---|---|---|
| `192.168.31.8:9881` | **P104-100 8GB** | ~1.3x 🚀 | ⭐ 主力（**同一台机器，主机不常开**） |
| `127.0.0.1:9881` | 920MX 2GB | ~0.13x 🐢 | 兜底（慢约 10 倍） |

- 两台机器**音色配置完全相同**，但性能差 10 倍 —— 别搞混。
- 本机 IP = `192.168.31.3`（有线）/ `192.168.31.5`（无线）。
- 脚本内置优先级：**`.8` 优先 → 本机兜底**（`NEKO_GROUP`）。
- 主机离线时：先 0.6s 快速 TCP 预探，**秒跳兜底**，不会卡满超时。
- ❌ 已下线：本机 `9880` / `192.168.31.6:9880` / `192.168.31.4:9880`。

**快速探活**：

```bash
curl -s -m 5 http://192.168.31.8:9881/api/v3/health
# {"status":"ok","version":"3.0.0","backend":"gsv","voices_count":8}
```

---

## 7. 常见坑 / 排障

| 现象 | 原因 / 处理 |
|---|---|
| **音色不对劲**（中文音色念日语） | 没切权重。按 §3.3 先调 `set_gpt_weights` + `set_sovits_weights` |
| HTTP 400 `...wav not exists` | `ref_audio_path` 或 `prompt_text` 与服务器不一致（注意中文字符）；也可能是**服务端正在重载配置**，重试即可 |
| **Windows 用 curl 报 400，但路径看着没错** | Git Bash / cmd 把中文参数按 **GBK** 发送 → 服务端收到乱码文件名。改用 Python（§3.4），或先编码 URL 再 curl（§3.6）。**已实测踩过** |
| 音频只播 1 秒多 | 走的是 v3 `/audio`（多 RIFF 分片）。改用 `GET /api/v2/tts` |
| 生成特别慢（60s+） | 连到了本机 2GB 兜底。检查 `.8` 是否开机 |
| 请求卡很久才回落 | 主机离线；已内置 0.6s 预探，若仍慢检查 `NEKO_TIMEOUT_MIN` |
| 连接被拒 / 超时 | 不在同一局域网，或服务未启动 |
| 文本里的 `(并行)` 被读出来 | 正常不会 —— 开头的模式标注会被自动剥离 |

---

## 8. 环境要求

- **Python 3.8+**（脚本仅用标准库，**无需 pip 安装任何包**）
- Windows（自动播放依赖 `winsound`；`--no-play` 时无此限制）
- 能访问局域网 `192.168.31.8:9881`
- 直接端到端 HTTP 调用（§3）则**任何语言/平台**均可

---

## 9. 文件清单

```
TTS加速器/
├── tts_auto.py            ← ⭐ 主力入口（自动降级）
├── tts_reply.py            ← 核心引擎（neko api 对接在这里）
├── tts_mixed.py            ← 中日英分段混读（备用）
├── check_tts_servers.py    ← 服务器在线检测
├── speak_result.txt        ← 最近一次结果（生成秒数,实时率）
└── README.md               ← 本文档
```

> 目录里另有 `tts_gui.py` / `tts_proxy.py` 等**旧架构**文件（9880 时代），当前已不使用。

**同步备份**：`H:\WorkBuddy\TTS加速器\`（`tts_reply.py` + `tts_auto.py`）
**改造前旧版**：`H:\WorkBuddy\Backup\TTS加速器\`

---

## 附：文本书写建议

- **称呼**：语音里统一用日文假名 **「せんせい」**，不用「老师」（中文读音）或「Sensei」（罗马字音调怪）。
- **多语言**：`text_lang=auto` 支持中/日/英混排，直接写整句即可，不要手动拆段。
- **标点**：用中文全角标点（`。！？…`），服务端 `cut5` 分句依赖它。
