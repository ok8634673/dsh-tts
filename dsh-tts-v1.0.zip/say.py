#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
DSH 用 TTS 客户端（GPT-SoVITS / neko api v2 直连）

用法:
    python say.py --list
    python say.py <文本>                      # 用默认音色 shun
    python say.py <音色> <文本> [--speed 1.0] [--play] [--out DIR]

说明:
  · 默认走 http://127.0.0.1:9881 （本机 neko api，本机以太网 IP 即 192.168.31.8）
  · 默认音色 shun = gsv 后端 / 显卡加速（老师指定）
  · *-onnx 系列 = genie 后端 / CPU 推理，声线较差，非必要不用
  · ref_audio_path / prompt_text 由服务端音色表自动取得，无需手写
  · 产物目录路径自适应：始终为本脚本所在目录下的 generated_audio\
    （TTS 文件夹整体搬走也自动跟随；可用 --out 或环境变量 DSH_TTS_OUT 覆盖）
  · --play 用 winsound 播放
"""
import argparse
import json
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

# ── 服务地址：自适应发现 ───────────────────────────────────────────
# 只开一台 TTS 服务器（双网卡冗余），会随「回老家 / 回广州」换网段：
#   老家：有线 192.168.28.6 / 无线 192.168.28.7
#   广州：192.168.31.8（本机曾以太网即此 IP）
# 策略：上次成功的地址(缓存) → 候选列表 → 同网段扫描 → 报错
TTS_PORT = 9881
KNOWN_BASES = [
    "http://127.0.0.1:9881",
    "http://192.168.28.6:9881",   # 老家 · 有线
    "http://192.168.28.7:9881",   # 老家 · 无线
    "http://192.168.31.8:9881",   # 广州
    "http://192.168.28.2:9881",
    "http://192.168.28.11:9881",
]
# 兼容旧代码引用
BASES = KNOWN_BASES

# ── 产物目录：路径自适应 ───────────────────────────────────────────
# 始终写到「程序根目录 / generated_audio」，即 say.py 所在文件夹下的 generated_audio。
# 整个 TTS 文件夹搬到任何位置（换盘、换机器、改中文名）都自动跟随，无需改代码。
# 原环境的 H:\WorkBuddy\generated_audio 在本机不存在，故不再使用。
# 覆盖优先级：命令行 --out > 环境变量 DSH_TTS_OUT > 自动推导
_APP_ROOT = os.path.dirname(os.path.abspath(__file__))
AUTO_OUT = os.path.join(_APP_ROOT, "generated_audio")
DEFAULT_OUT = os.environ.get("DSH_TTS_OUT") or AUTO_OUT
# 上次成功地址的缓存文件（写在程序根目录，跟着 TTS 文件夹走）
BASE_CACHE = os.path.join(_APP_ROOT, ".tts_base_cache")

# ⚠️ 默认音色 = shun（gsv 后端，显卡加速）—— 2026-10-15 老师纠正：
#    不要用 *-onnx（backend=genie，CPU 推理，声线会飘）
DEFAULT_VOICE = "shun"

# 别名 -> 服务端 voice id
ALIASES = {
    # —— GPU / gsv 后端（推荐）——
    "shun": "shun",
    "春原瞬": "shun",
    "shun-jp": "shun-jp",
    "春原瞬jp": "shun-jp",
    "kokona": "kokona",
    "春原心奈": "kokona",
    "ibuki": "ibuki",
    "丹花伊吹": "ibuki",
    # —— CPU / ONNX（genie）：仅在明确需要省显存时使用，声线质量较差 ——
    "shun-onnx": "shun-onnx",
    "shun_onnx": "shun-onnx",
    "瞬onnx": "shun-onnx",
    "kokona-onnx": "kokona-onnx",
    "心奈onnx": "kokona-onnx",
    "ibuki-onne": "ibuki-onne",
    "伊吹onnx": "ibuki-onne",
}

# 无音色表时的兜底（服务端 /api/v3/voices 拿不到时用）
FALLBACK = {
    "shun-onnx": {
        "ref_audio_path": "api_neko/voices/shun-しゅ、シュンお姉さんはどこに行ったんでしょうね？.wav",
        "prompt_text": "しゅ、シュンお姉さんはどこに行ったんでしょうね？",
        "prompt_lang": "all_ja",
        "text_lang": "all_zh",
    },
    "kokona-onnx": {
        "ref_audio_path": "api_neko/voices/kokona-我是训育支援部梅花园的心奈！ 别，别看我小，我可是正经的教官哦？！.wav",
        "prompt_text": "我是训育支援部梅花园的心奈！ 别，别看我小，我可是正经的教官哦？！",
        "prompt_lang": "all_zh",
        "text_lang": "all_zh",
    },
    "ibuki-onne": {
        "ref_audio_path": "api_neko/voices/ibuki-終わったら先生と遊ぼうっと.wav",
        "prompt_text": "終わったら先生と遊ぼうっと",
        "prompt_lang": "all_ja",
        "text_lang": "all_zh",
    },
    "shun": {
        "ref_audio_path": "api_neko/voices/shun-请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！.wav",
        "prompt_text": "请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！",
        "prompt_lang": "all_zh",
        "text_lang": "auto",
    },
    "shun-jp": {
        "ref_audio_path": "api_neko/voices/shun-しゅ、シュンお姉さんはどこに行ったんでしょうね？.wav",
        "prompt_text": "しゅ、シュンお姉さんはどこに行ったんでしょうね？",
        "prompt_lang": "all_ja",
        "text_lang": "auto",
    },
    "kokona": {
        "ref_audio_path": "api_neko/voices/kokona-我是训育支援部梅花园的心奈！ 别，别看我小，我可是正经的教官哦？！.wav",
        "prompt_text": "我是训育支援部梅花园的心奈！ 别，别看我小，我可是正经的教官哦？！",
        "prompt_lang": "all_zh",
        "text_lang": "auto",
    },
    "ibuki": {
        "ref_audio_path": "api_neko/voices/ibuki-終わったら先生と遊ぼうっと.wav",
        "prompt_text": "終わったら先生と遊ぼうっと",
        "prompt_lang": "all_ja",
        "text_lang": "auto",
    },
}


def _health_ok(base, timeout=2.0):
    """探测某个 base 是否为可用的 neko api"""
    try:
        with urllib.request.urlopen(base.rstrip("/") + "/api/v3/health", timeout=timeout) as r:
            if r.status != 200:
                return False
            body = r.read(400).decode("utf-8", "ignore")
            return '"status"' in body and "ok" in body
    except Exception:
        return False


def _read_cached_base():
    try:
        with open(BASE_CACHE, "r", encoding="utf-8") as f:
            b = f.read().strip()
        return b or None
    except Exception:
        return None


def _write_cached_base(base):
    try:
        with open(BASE_CACHE, "w", encoding="utf-8") as f:
            f.write(base)
    except Exception:
        pass


def _local_subnets():
    """取本机所有 IPv4 /24 网段前缀，如 192.168.28."""
    hosts = []
    try:
        out = subprocess.run(
            ["ipconfig"], capture_output=True, text=True, timeout=8,
            encoding="gbk", errors="replace",
        ).stdout
        for m in re.finditer(r"IPv4[^:]*:\s*(\d+\.\d+\.\d+)\.\d+", out):
            p = m.group(1)
            if p not in hosts and not p.startswith("127.") and not p.startswith("169.254."):
                hosts.append(p)
    except Exception:
        pass
    return hosts


def _scan_subnet(prefix, port=TTS_PORT, timeout=0.35):
    """并发扫一个 /24 网段，返回第一个响应的 TTS base"""
    import socket
    import concurrent.futures

    def probe(last):
        host = f"{prefix}.{last}"
        try:
            s = socket.create_connection((host, port), timeout=timeout)
            s.close()
            return host
        except Exception:
            return None

    with concurrent.futures.ThreadPoolExecutor(max_workers=64) as ex:
        for host in ex.map(probe, range(1, 255)):
            if host:
                return host
    return None


def pick_base(verbose=True):
    """按「缓存 → 候选列表 → 同网段扫描」发现可用服务，成功后写入缓存"""
    # 1) 上次成功的地址
    cached = _read_cached_base()
    if cached and _health_ok(cached):
        if verbose:
            print(f"[服务] 使用上次地址 {cached}")
        return cached

    # 2) 已知候选
    for b in KNOWN_BASES:
        if _health_ok(b):
            _write_cached_base(b)
            if verbose:
                print(f"[服务] 自动发现 {b}")
            return b

    # 3) 同网段扫描
    for prefix in _local_subnets():
        host = _scan_subnet(prefix)
        if host:
            b = f"http://{host}:{TTS_PORT}"
            if _health_ok(b, timeout=3):
                _write_cached_base(b)
                if verbose:
                    print(f"[服务] 网段扫描发现 {b}")
                return b

    raise SystemExit(
        "[错误] 找不到可用的 TTS 服务。\n"
        f"  已试: 缓存={cached} 候选={', '.join(KNOWN_BASES)}\n"
        f"  并扫描了本机网段。请确认 TTS 服务器已开机，或用 --base 手动指定。"
    )


def fetch_voices(base, timeout=10):
    """取服务端音色表 -> {voice_id: cfg}"""
    try:
        with urllib.request.urlopen(base + "/api/v3/voices/full", timeout=timeout) as r:
            data = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        print(f"[警告] 读取音色表失败({e})，改用内置兜底配置", file=sys.stderr)
        return {}
    out = {}
    for item in data:
        vid = item.get("voice", {}).get("id")
        if not vid:
            continue
        ref = item.get("ref_audio") or {}
        params = item.get("params") or {}
        model = item.get("model") or {}
        out[vid] = {
            "name": item.get("voice", {}).get("name", vid),
            "ref_audio_path": ref.get("path", ""),
            "prompt_text": ref.get("prompt_text", ""),
            "prompt_lang": ref.get("prompt_lang", "all_zh"),
            "text_lang": params.get("text_lang", "auto"),
            "backend": model.get("backend", ""),
            "onnx_model_dir": model.get("onnx_model_dir", ""),
            "version": model.get("version", ""),
        }
    return out


def list_voices(voices):
    print(f"{'voice_id':<14} {'backend':<7} {'ver':<4} {'推理':<6} 名称")
    print("-" * 70)
    for vid, v in voices.items():
        onnx = "CPU" if (v.get("onnx_model_dir") or v.get("backend") == "genie") else "GPU"
        mark = " ⭐默认" if vid == DEFAULT_VOICE else ""
        print(f"{vid:<14} {(v.get('backend') or '-'):<7} {(v.get('version') or '-'):<4} {onnx:<6} {v.get('name')}{mark}")


def safe_name(s, limit=20):
    s = re.sub(r'[\\/:*?"<>|\r\n\t]', "", s)
    return s[:limit] or "audio"


def synth(base, voice_id, cfg, text, speed, out_dir, timeout=600, parallel=True):
    # 先建目录：不存在就自动创建（自适应路径第一次运行时需要）
    os.makedirs(out_dir, exist_ok=True)
    q = urllib.parse.urlencode({
        "text": text,
        "text_lang": cfg.get("text_lang") or "auto",
        "ref_audio_path": cfg["ref_audio_path"],
        "prompt_text": cfg["prompt_text"],
        "prompt_lang": cfg.get("prompt_lang") or "all_zh",
        "text_split_method": "cut5",
        "speed_factor": speed,
        "top_k": 15,
        "top_p": 1.0,
        "temperature": 1.0,
        "repetition_penalty": 1.35,
        # 2GB 显存（920MX 保底机）对长文本并行推理会 OOM，可用 --serial 关掉
        "parallel_infer": bool(parallel),
        "streaming_mode": False,
        "return_fragment": False,
    })
    url = base + "/api/v2/tts?" + q
    t0 = time.time()
    with urllib.request.urlopen(url, timeout=timeout) as r:
        raw = r.read()
    dt = time.time() - t0
    if not raw.startswith(b"RIFF"):
        raise SystemExit(f"[错误] 返回不是 WAV（前 200 字节）: {raw[:200]!r}")
    os.makedirs(out_dir, exist_ok=True)
    ts = time.strftime("%Y%m%d_%H%M%S")
    path = os.path.join(out_dir, f"{voice_id}-{safe_name(text)}-{ts}.wav")
    with open(path, "wb") as f:
        f.write(raw)
    return path, dt, len(raw)


def wav_seconds(path):
    try:
        import wave
        with wave.open(path, "rb") as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return -1.0


def play(path):
    """播放音频；阻塞到播完（方便「说完再做下一件事」）。返回 True=正常播完。"""
    try:
        import winsound
        winsound.PlaySound(path, winsound.SND_FILENAME)
        return True
    except Exception as e:
        print(f"[警告] 播放失败({e})，音频已保存: {path}", file=sys.stderr)
        return False


def main():
    ap = argparse.ArgumentParser(add_help=True)
    ap.add_argument("voice", nargs="?", help=f"音色（默认 {DEFAULT_VOICE}；也可省略音色直接给文本）")
    ap.add_argument("text", nargs="?", help="要合成的文本")
    ap.add_argument("--voice", dest="voice_opt", default=None, help=f"显式指定音色（默认 {DEFAULT_VOICE}）")
    ap.add_argument("--list", action="store_true", help="列出服务端音色")
    ap.add_argument("--speed", type=float, default=1.0)
    ap.add_argument("--play", action="store_true", help="合成后播放")
    ap.add_argument("--serial", action="store_true", help="串行推理（parallel_infer=False），2GB 显存保活用")
    ap.add_argument("--status", action="store_true", help="只显示服务发现与健康状态，不合成")
    ap.add_argument("--out", default=DEFAULT_OUT, help="产物目录（默认：脚本所在目录\\generated_audio，自适应）")
    ap.add_argument("--base", default=None, help="手动指定服务地址，如 http://192.168.28.7:9881")
    ap.add_argument("--timeout", type=int, default=600)
    args = ap.parse_args()

    if args.status:
        cached = _read_cached_base()
        print(f"[缓存] 上次地址: {cached or '（无）'}")
        print(f"[产物] {os.path.abspath(args.out)}")
        probes = []
        for b in ([cached] if cached else []) + KNOWN_BASES:
            if b and b not in probes:
                probes.append(b)
        for b in probes:
            ok = _health_ok(b, timeout=3)
            print(f"  {b:<32} {'✓ 在线' if ok else '✗ 不可达'}")
        return 0

    if args.base:
        base = args.base.rstrip("/")
        if not _health_ok(base, timeout=6):
            print(f"[警告] 指定的 --base {base} 健康检查失败，仍尝试使用", file=sys.stderr)
    else:
        base = pick_base()
    voices = fetch_voices(base)

    if args.list:
        list_voices(voices)
        print(f"\n[产物目录] {os.path.abspath(args.out)}" + ("" if os.path.abspath(args.out) == AUTO_OUT else "（已被 --out/环境变量覆盖）"))
        return 0

    # 省略音色时：单参数 = 文本（用默认音色）；两参数 = 音色 + 文本
    raw_voice, text = args.voice_opt or args.voice, args.text
    if text is None and raw_voice is not None:
        raw_voice, text = None, raw_voice
    if not text:
        ap.print_help()
        return 2

    vid = ALIASES.get(raw_voice or DEFAULT_VOICE, raw_voice or DEFAULT_VOICE)
    cfg = voices.get(vid)
    if cfg is None:
        cfg = FALLBACK.get(vid)
        if cfg is None:
            print(f"[错误] 未知音色 '{raw_voice}'。可用: {', '.join(sorted(voices) or sorted(FALLBACK))}", file=sys.stderr)
            return 2
        print(f"[提示] 服务端音色表无 '{vid}'，使用内置兜底配置", file=sys.stderr)

    backend = cfg.get("backend") or "-"
    onnx = cfg.get("onnx_model_dir") or "-"
    print(f"[服务] {base}")
    print(f"[音色] {vid}  backend={backend}  onnx={onnx}")
    print(f"[产物] {os.path.abspath(args.out)}")
    if onnx != "-" or backend == "genie":
        print("[警告] 该音色走 CPU 推理（ONNX），声线质量较差；老师指定默认用 shun（gsv/显卡加速）", file=sys.stderr)

    mode = "串行" if args.serial else "并行"
    if args.serial:
        print("[模式] 串行推理（parallel_infer=False）")
    try:
        path, dt, size = synth(base, vid, cfg, text, args.speed, args.out, args.timeout,
                               parallel=not args.serial)
    except Exception as e:
        # 并行失败（常见于 2GB 显存 OOM / 超时）→ 自动降级串行重试一次
        if args.serial:
            raise
        print(f"[降级] {mode}推理失败（{type(e).__name__}: {e}）→ 改用串行重试", file=sys.stderr)
        path, dt, size = synth(base, vid, cfg, text, args.speed, args.out, args.timeout, parallel=False)
        print("[模式] 已降级为串行推理")
    dur = wav_seconds(path)
    print(f"[AUDIO_FILE]{path}")
    print(f"[统计] 生成 {dt:.2f}s | 音频时长 {dur:.2f}s | 实时率 {dur / dt if dt else 0:.2f}x | {size / 1024:.1f}KB")
    if args.play:
        play(path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
