"""
WorkBuddy TTS 自动备用模式包装器
四档策略：并行 → 流式 → 串行+流式 → 报错
用法：python tts_auto.py "角色名" "回复文本" [--lang zh] [--quiet]
  --quiet  : 只输出关键信息（音频路径+耗时），不输出详细日志
  --lang   : 指定语言 (zh/ja/en)

四档策略（2026-07-10，2026-07-22 B方案，2026-07-23 Tier4更新）：
  Tier 0   | 流式探针预检          → 验证服务器是否真的在线
  Tier 0.5 | 字数判定（B方案新增）  → >40字直接跳流式，避免2GB显存OOM
  Tier 1   | GPU空闲 + 探针通过 + ≤40字 → 并行推理，全速
  Tier 2   | GPU被占 或 探针失败 或 >40字 → 流式推理，保活
  Tier 3   | 流式超时/失败              → 串行+流式，终极保活
  Tier 4   | 全部失败                   → 自动重启服务器 + 流式重试（2026-07-23新增）

硬超时保护（2026-07-10 重构：纯字数驱动，无固定上限）：
  - 动态安全系数：safety = max(1.3, 3.0 - 0.02×字数)
    短文本高系数（固定开销波动大），长文本低系数（推理稳定）
    例：5字→2.9x, 20字→2.6x, 50字→2.0x, 85字→1.3x(触底)
  - 超时 = 预测耗时 × 安全系数，不设固定上限
  - 保底最小值：并行15s / 流式30s / 串行+流式60s

2026-07-10 压测数据（920MX 2GB, 32字）：
  - 并行非流式: ~12s  (BERT并行，一次性WAV)
  - 并行流式:   ~12.5s (BERT并行，分块传输+停滞检测)
  - 串行非流式: ~30s  (BERT串行，一次性WAV)
  - 串行流式:   ~32.7s (BERT串行，分块传输+停滞检测) ← 究极保活
  - 结论：流式与并行总延迟几乎相同，串行慢2.5x但显存安全
"""
import sys
import os
import subprocess
import time
import re

# ── 路径配置 ──
_HERE = os.path.dirname(os.path.abspath(__file__))
TTS_SCRIPT = os.path.join(_HERE, "tts_reply.py")
AUDIO_DIR = r"H:\WorkBuddy\generated_audio"

# ── 推理模式标注剥离（2026-08-05新增，与 tts_reply.py 保持一致）──
# 朗读文本开头的 "(并行)" 等模式标注仅用于文字展示，不朗读、不计入字数
MODE_ANNOTATION_RE = re.compile(
    r'^[（(]\s*(?:并行|流式|串行|探针|重启|混读|混合|静默|Tier\s*\d|B方案|回退|自动|GPU|CPU)[^）)]*[）)]\s*'
)

def strip_mode_annotation(text):
    """剥离开头的推理模式标注（如 (并行)、（串行+流式）），返回纯净朗读文本"""
    if not text:
        return text
    return MODE_ANNOTATION_RE.sub('', text, count=1)


def get_latest_audio(after_time=None):
    """获取最新的音频文件路径，可指定只找 after_time 之后创建的"""
    if not os.path.isdir(AUDIO_DIR):
        return None
    files = []
    for f in os.listdir(AUDIO_DIR):
        if f.endswith('.wav'):
            path = os.path.join(AUDIO_DIR, f)
            mtime = os.path.getmtime(path)
            if after_time is None or mtime > after_time:
                files.append((mtime, path))
    if files:
        files.sort(reverse=True)
        return files[0][1]
    return None


def check_gpu():
    """
    检测 Compute_0 活跃进程数（GPU被占判断）
    返回:
        进程数 (int): Compute_0 上活跃的进程数（已过滤系统进程）
        -1: 检测失败（权限不足/PowerShell不可用等）
    
    判断逻辑（2026-07-08 实测验证）：
      - TTS 独占时 = 1 个进程（GPT-SoVITS python）
      - 游戏抢占时 ≥ 2 个进程
      - 空闲时 = 0
    
    过滤规则：
      - 排除 dwm/csrss/System/svchost 等系统进程（偶发占用，不影响TTS）
      - 排除占用 < 5% 的背景噪音
    """
    ps_cmd = (
        '$samples = Get-Counter -Counter "\\GPU Engine(*)\\Utilization Percentage"'
        ' -ErrorAction SilentlyContinue | Select-Object -ExpandProperty CounterSamples;'
        '$count = 0;'
        '$skip = @("dwm","csrss","System","svchost","Idle","powershell");'
        'foreach ($s in $samples) {'
        '  if ($s.Path -like "*compute_0*" -and $s.CookedValue -ge 5) {'
        '    $p = [regex]::Match($s.Path,"pid_(\\d+)").Groups[1].Value;'
        '    $n = (Get-Process -Id $p -ea 0).ProcessName;'
        '    if ($n -notin $skip) { $count++ }'
        '  }'
        '};'
        '$count'
    )
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-Command", ps_cmd],
            capture_output=True, text=True, timeout=10,
            encoding='gbk', errors='replace'
        )
        output = result.stdout.strip().split('\n')[-1].strip()
        if output.isdigit():
            return int(output)
        return -1
    except Exception:
        return -1


def check_gpu_util():
    """
    用 nvidia-smi 查询 GPU 利用率百分比
    返回: (utilization%, memory_used_MiB) 或 (-1, -1) 失败
    
    2026-07-10 压测参考值：
      - TTS 推理期间 max: 100%（计算突发）
      - TTS 推理期间 avg: ~56%（含 I/O 等待）
      - GPU 空闲: 0-10%
      - 游戏运行: 30-80%（视游戏而定）
    """
    try:
        result = subprocess.run(
            ["nvidia-smi",
             "--query-gpu=utilization.gpu,memory.used",
             "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split(',')
            if len(parts) >= 2:
                return int(parts[0].strip()), int(parts[1].strip())
    except Exception:
        pass
    return -1, -1


def server_health_check(role, lang=None, timeout=15):
    """
    流式探针：用空格字符的流式请求检测服务器是否在线响应
    
    原理：流式模式首字节返回快（~2s），如果服务器卡死则不会有任何数据
    用途：在正式推理前快速判断服务器状态，避免并行超时浪费
    空格字符无实际语音内容，仅为服务器存活检测，不会产生可听音频
    
    返回: True=服务器在线可推理, False=服务器无响应/卡死
    
    2026-07-10 新增：流式探针预检机制
    """
    cmd = [sys.executable, TTS_SCRIPT, role, "你好呀", "--streaming", "--no-save", "--no-parallel"]
    if lang:
        cmd.extend(["--lang", lang])
    try:
        result = subprocess.run(
            cmd,
            capture_output=True, text=True, timeout=timeout,
            encoding='utf-8'
        )
        # 只要返回码是0（即使超时被流式停滞检测截断），说明服务器响应了
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        # 15s 内无任何响应 → 服务器卡死
        return False
    except Exception:
        return False


def run_tts(role, text, streaming=False, timeout=60, lang=None, no_parallel=False, no_play=False, speed=None):
    """
    调用 tts_reply.py 执行TTS合成
    返回: (success: bool, output: str, elapsed: float)
    
    no_parallel=True: 串行BERT推理（parallel_infer=False），显存安全但慢2.5x
    no_play=True: 不自动播放（混读中间段使用）
    speed: 语速覆盖（1.0=正常，>1快，<1慢），None=用角色默认
    """
    cmd = [sys.executable, TTS_SCRIPT, role, text, "--verbose"]
    if streaming:
        cmd.append("--streaming")
    if no_parallel:
        cmd.append("--no-parallel")
    if lang:
        cmd.extend(["--lang", lang])
    if speed is not None:
        cmd.extend(["--speed", str(speed)])
    if no_play:
        cmd.append("--no-play")

    start = time.time()
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding='utf-8'
        )
        elapsed = time.time() - start
        output = (result.stdout or "") + (result.stderr or "")
        if result.returncode == 0:
            return True, output, elapsed
        else:
            return False, output, elapsed
    except subprocess.TimeoutExpired:
        elapsed = time.time() - start
        return False, "TIMEOUT", elapsed
    except Exception as e:
        elapsed = time.time() - start
        return False, f"ERROR: {type(e).__name__}: {e}", elapsed


def main():
    # ── 解析参数 ──
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    lang = None
    quiet = False
    no_play = False
    speed = None

    for i, a in enumerate(sys.argv):
        if a.startswith("--lang="):
            lang = a.split("=", 1)[1]
        elif a == "--lang" and i + 1 < len(sys.argv):
            lang = sys.argv[i + 1]
        if a.startswith("--speed="):
            try:
                speed = float(a.split("=", 1)[1])
            except ValueError:
                pass
        elif a == "--speed" and i + 1 < len(sys.argv):
            try:
                speed = float(sys.argv[i + 1])
            except ValueError:
                pass
        if a == "--quiet":
            quiet = True
        if a == "--no-play":
            no_play = True

    if len(args) < 2:
        print("用法: python tts_auto.py <角色名> <文本> [--lang zh] [--quiet] [--no-play] [--speed X]")
        print("  --quiet  : 精简输出（只输出关键信息）")
        print("  --lang   : 指定语言 (zh/ja/en)")
        print("  --no-play: 不自动播放（混读合并时中间段使用）")
        print("  --speed X: 语速覆盖（1.0=正常，>1快，<1慢；默认用角色配置）")
        sys.exit(1)

    role, text = args[0], args[1]
    # 剥离模式标注（如"(并行)"），字数判定与朗读均不含标注（2026-08-05新增）
    text = strip_mode_annotation(text)
    text_len = len(text.strip())
    t0 = time.time()  # 记录开始时间，用于查找新生成的音频

    # ── 并行模式字数上限（2026-07-22 B方案：字数判定）──
    # 920MX 2GB显存，并行BERT对>40字文本会OOM卡死
    # 压测数据：并行 vs 流式速度几乎相同（12.0s vs 11.8s），跳过无损
    PARALLEL_MAX_CHARS = 40

    # ── GPU可用显存阈值（2026-07-23 新增）──
    # GPT-SoVITS模型需要~1300MB GPU显存
    # 如果剩余显存<700MB，模型无法加载到GPU → 并行和流式都会卡死
    # 此时直接跳到Tier3串行+流式（BERT走CPU，虽然慢但能跑）
    GPU_MIN_FREE_MEM = 700  # MiB
    GPU_TOTAL_MEM = 2048    # 920MX 2GB

    # ── 智能超时策略（2026-07-10 重构：纯字数驱动，无固定上限）──
    #
    # 回归模型（GPT-SoVITS 本地 GPU 推理，R²≈0.99）：
    #   并行模式：~0.85s/字 + 9s基础  (GPU空闲全速)
    #   流式模式：~2.0s/字 + 15s基础  (GPU被占保活)
    #   串行+流式：~3.0s/字 + 15s基础 (终极保活，显存安全)
    #
    # 动态安全系数（2026-07-10 重构）：
    #   短文本波动大 → 高系数（固定开销占比大，不可预测）
    #   长文本稳定 → 低系数（推理时间主导，回归模型更准）
    #   safety = max(1.3, 3.0 - 0.02 × 字数)  → 范围 [1.3, 3.0]
    #   例：5字=2.9x, 20字=2.6x, 50字=2.0x, 85字=1.3x(触底)
    #
    # 硬超时 = max(绝对最小值, 预测 × 安全系数)
    #   不再设固定上限（如300s/480s），完全由字数驱动
    #   绝对最小值防止超短文本被误杀
    safety = max(1.3, 3.0 - text_len * 0.02)

    # Tier1: 并行推理
    pred_p = 9 + 0.85 * text_len
    parallel_timeout = max(15, int(pred_p * safety))

    # Tier2: 流式推理（GPU被占）
    pred_s = 15 + 2.0 * text_len
    streaming_timeout = max(30, int(pred_s * safety))

    # Tier3: 串行+流式（终极保活）
    pred_ss = 15 + 3.0 * text_len
    serial_streaming_timeout = max(60, int(pred_ss * safety))

    if not quiet:
        print(f"[自动模式] 角色={role}, 文本={text_len}字, 安全系数={safety:.2f}")
        print(f"[自动模式] T1并行={parallel_timeout}s | T2流式={streaming_timeout}s | T3串行+流式={serial_streaming_timeout}s")

    # ── GPU状态检测（2026-07-10 增强：进程数 + 利用率双检测）──
    # 提前判断 Compute_0 是否被抢占，避免游戏时白等并行超时
    # 2026-07-10 压测结论：
    #   - 并行 vs 流式延迟几乎相同（12.0s vs 11.8s），切换不损失性能
    #   - 2+ Compute_0 进程 = GPU被其他程序占用 → 直接走流式
    #   - GPU利用率作为辅助参考，帮助判断 GPU 争用程度
    gpu_procs = check_gpu()
    gpu_util, gpu_mem = check_gpu_util()
    gpu_free_mem = GPU_TOTAL_MEM - gpu_mem if gpu_mem > 0 else -1
    # GPU显存不足时，直接跳到Tier3串行+流式（BERT走CPU）
    skip_to_serial = (gpu_free_mem > 0 and gpu_free_mem < GPU_MIN_FREE_MEM)
    if not quiet:
        if gpu_procs == -1:
            print(f"[GPU检测] 进程数检测失败（跳过）, 利用率={gpu_util}%, 显存={gpu_mem}MiB, 可用={gpu_free_mem}MiB")
        elif gpu_procs == 0:
            mem_note = f"⚠️ 可用={gpu_free_mem}MiB<{GPU_MIN_FREE_MEM}MB → 直接Tier3串行" if skip_to_serial else f"可用={gpu_free_mem}MiB → Tier1 并行"
            print(f"[GPU检测] Compute_0空闲, GPU利用={gpu_util}%, 显存={gpu_mem}MiB, {mem_note}")
        elif gpu_procs == 1:
            mem_note = f"⚠️ 可用={gpu_free_mem}MiB<{GPU_MIN_FREE_MEM}MB → 直接Tier3串行" if skip_to_serial else f"可用={gpu_free_mem}MiB → Tier1 并行"
            print(f"[GPU检测] Compute_0=1(TTS独占), GPU利用={gpu_util}%, 显存={gpu_mem}MiB, {mem_note}")
        else:
            print(f"[GPU检测] Compute_0={gpu_procs}进程, GPU利用={gpu_util}%, 显存={gpu_mem}MiB ⚠️ GPU被抢占 → Tier2 流式推理")

    # ═══════════════════════════════════════════
    # 步骤0：流式探针预检（2026-07-10 新增）
    # 在 GPU 看似空闲时，用流式请求验证服务器是否真的能响应
    # 避免并行超时浪费在已卡死的服务器上
    # ═══════════════════════════════════════════
    skip_parallel = (gpu_procs >= 2) or skip_to_serial
    skip_reason = ""

    if gpu_procs >= 2:
        skip_reason = f"GPU已被{gpu_procs}个进程占用"
    elif skip_to_serial:
        skip_reason = f"GPU可用显存={gpu_free_mem}MiB<{GPU_MIN_FREE_MEM}MB（模型无法加载到GPU）"

    # ── neko api 优先（2026-10-12 新增）──
    # neko api 是"服务端自管显存"的新架构，客户端的 GPU 预检 / >40字判定
    # 都是旧架构（本机 920MX 2GB 直接跑推理）的遗留逻辑：
    #   neko 进程长期占着本机显存 → 可用显存永远 <700MB → 每次都被误判降级到
    #   最慢的 Tier3「串行+流式」（实测 27.8s，而服务端其实只要 6.5s）
    # 因此：只要 neko 在线，就跳过全部本地预判，直接走 Tier1 并行推理。
    neko_online = False
    try:
        import socket as _socket
        # 优先 31.8（P104-100 8GB），兜底本机 2GB（2026-10-12）
        # 超时 0.6s：LAN 在线主机 <50ms 响应，离线主机会卡满超时 → 不宜设长
        for _h in ("192.168.31.8", "127.0.0.1"):
            try:
                _sock = _socket.create_connection((_h, 9881), timeout=0.6)
                _sock.close()
                neko_online = True
                break
            except Exception:
                continue
    except Exception:
        neko_online = False

    if neko_online:
        skip_parallel = False
        skip_reason = ""
        if not quiet:
            print("[neko] 服务在线（服务端自管显存）→ 跳过GPU预检与字数判定，直接并行")

    if not skip_parallel and not neko_online:
        # GPU 看起来空闲，但先验证服务器是否真的在线
        # 注意：显存不足时跳过探针（探针也用parallel_infer=True会卡死）
        if skip_to_serial:
            if not quiet:
                print(f"[预检] 跳过探针（GPU显存不足，探针也会OOM）")
        else:
            if not quiet:
                print(f"[预检] 流式探针验证服务器可用性（15s超时）...")
            server_alive = server_health_check(role, lang=lang, timeout=15)
            if not server_alive:
                if not quiet:
                    print(f"[预检] ✗ 服务器无响应 → 跳过并行，直接走流式保活")
                skip_parallel = True
                skip_reason = "流式探针检测到服务器无响应"
            else:
                if not quiet:
                    print(f"[预检] ✓ 服务器响应正常 → 进入并行推理")

    # ═══════════════════════════════════════════
    # 字数判定（2026-07-22 B方案新增：>40字跳过并行）
    # 920MX 2GB显存，并行BERT对长文本会OOM卡死
    # 压测已证明并行 vs 流式速度几乎相同，跳过无损
    # ═══════════════════════════════════════════
    if not skip_parallel and not neko_online and text_len > PARALLEL_MAX_CHARS:
        if not quiet:
            print(f"[字数判定] {text_len}字 > {PARALLEL_MAX_CHARS}字上限 → 跳过并行，直接流式（避免2GB显存OOM）")
        skip_parallel = True
        skip_reason = f"字数{text_len}超过{PARALLEL_MAX_CHARS}字上限（避免2GB显存OOM）"

    # ═══════════════════════════════════════════
    # 步骤1：尝试并行模式（≤40字快速，但GPU忙时可能卡死）
    # ═══════════════════════════════════════════

    if skip_parallel:
        if not quiet:
            print(f"[策略] 跳过并行模式（{skip_reason}）")
        # 直接标记并行失败，进入流式模式
        success = False
        output = "SKIPPED"
        elapsed = 0
    else:
        if not quiet:
            print(f"\n[步骤1/3] 并行模式...")

        success, output, elapsed = run_tts(
            role, text, streaming=False,
            timeout=parallel_timeout, lang=lang, no_play=no_play, speed=speed
        )

        if success:
            # 提取耗时和加速比
            info = ""
            for line in output.split('\n'):
                if '[完成]' in line or '[保存]' in line:
                    info += line.strip() + " "

            audio = get_latest_audio(t0)
            if not quiet:
                print(f"[✓] 并行模式成功 ({elapsed:.1f}s)")
                if info:
                    print(f"  {info.strip()}")
            # 机器可读输出
            print(f"[MODE]并行模式")
            print(f"[AUDIO_FILE]{audio}")
            return

        if not quiet:
            print(f"[✗] 并行模式失败: {output[:80]} ({elapsed:.1f}s)")

    # ═══════════════════════════════════════════
    # 步骤2：切换流式模式（慢但能看到进度，不会黑盒等待）
    # 注意：流式模式仍用parallel_infer=True，GPU显存不足时也会卡死
    # 2026-07-23：显存不足时跳过此步，直接到Tier3串行+流式
    # ═══════════════════════════════════════════
    if skip_to_serial:
        if not quiet:
            print(f"\n[步骤2/3] 跳过流式模式（GPU显存不足，parallel_infer也会OOM）→ 直接Tier3串行+流式")
        success = False
        output = "SKIPPED_GPU_MEM"
        elapsed = 0
    else:
        if not quiet:
            print(f"\n[步骤2/3] → 自动切换流式模式...")

        success, output, elapsed = run_tts(
            role, text, streaming=True,
            timeout=streaming_timeout, lang=lang, no_play=no_play, speed=speed
        )

    if success:
        info = ""
        for line in output.split('\n'):
            if '[完成]' in line or '[保存]' in line:
                info += line.strip() + " "

        audio = get_latest_audio(t0)
        if not quiet:
            print(f"[✓] 流式模式成功 ({elapsed:.1f}s)")
            if info:
                print(f"  {info.strip()}")
        print(f"[MODE]流式模式")
        print(f"[AUDIO_FILE]{audio}")
        return

    # ═══════════════════════════════════════════
    # 步骤3：串行+流式终极保活（2026-07-10 新增）
    # 场景：3+游戏争用GPU、显存紧张、流式模式也超时/失败
    # parallel_infer=False + streaming_mode=True
    # 代价：慢2.6x（32.7s vs 12.5s，32字），但不崩溃不OOM
    # ═══════════════════════════════════════════
    if not quiet:
        print(f"[✗] 流式模式也失败: {output[:80]} ({elapsed:.1f}s)")
        print(f"\n[步骤3/3] → 终极保活：串行BERT + 流式传输...")

    success3, output3, elapsed3 = run_tts(
        role, text, streaming=True,
        timeout=serial_streaming_timeout, lang=lang,
        no_parallel=True, no_play=no_play, speed=speed
    )

    if success3:
        info = ""
        for line in output3.split('\n'):
            if '[完成]' in line or '[保存]' in line:
                info += line.strip() + " "

        audio = get_latest_audio(t0)
        if not quiet:
            print(f"[✓] 串行+流式终极保活成功 ({elapsed3:.1f}s)")
            if info:
                print(f"  {info.strip()}")
        print(f"[MODE]串行+流式(终极保活)")
        print(f"[AUDIO_FILE]{audio}")
        return

    # 三种模式都失败
    if not quiet:
        print(f"[✗] 串行+流式也失败: {output3[:80]} ({elapsed3:.1f}s)")
        print(f"\n[步骤4/4] → 自动重启服务器 + 流式重试...")

    # ═══════════════════════════════════════════
    # Tier 4：自动重启服务器 + 流式重试（2026-07-23 新增）
    # 场景：服务器GPU推理线程卡死（端口通但无法推理）
    # 策略：发送 /control?command=restart → 等待模型重新加载 → 流式重试
    # ═══════════════════════════════════════════
    import urllib.request as _urllib_req
    import urllib.parse as _urllib_parse

    restart_success = False
    for server_url in ["http://127.0.0.1:9880"]:
        try:
            base = server_url
            ctrl_url = f"{base}/control?command=restart"
            if not quiet:
                print(f"[重启] 发送重启指令到 {base}...")
            req = _urllib_req.Request(ctrl_url)
            _urllib_req.urlopen(req, timeout=10)
            restart_success = True
            if not quiet:
                print(f"[重启] ✓ 重启指令已发送")
        except Exception as e:
            if not quiet:
                print(f"[重启] {base} 重启指令发送失败: {e}（服务器可能已在关闭中）")
            # 连接失败可能是因为服务器正在关闭（重启过程中端口会断一下）
            # 这其实是正常的，不算失败
            restart_success = True

    if restart_success:
        # 等待服务器重新加载模型（GPT-SoVITS通常需要15-30秒）
        if not quiet:
            print(f"[重启] 等待30秒让模型重新加载...")
        time.sleep(30)

        # 用流式模式重试
        retry_timeout = max(60, int(pred_s * 2.0))  # 重试给充足时间
        success4, output4, elapsed4 = run_tts(
            role, text, streaming=True,
            timeout=retry_timeout, lang=lang, no_play=no_play, speed=speed
        )

        if success4:
            info = ""
            for line in output4.split('\n'):
                if '[完成]' in line or '[保存]' in line:
                    info += line.strip() + " "

            audio = get_latest_audio(t0)
            if not quiet:
                print(f"[✓] 重启后流式重试成功 ({elapsed4:.1f}s)")
                if info:
                    print(f"  {info.strip()}")
            print(f"[MODE]重启+流式(Tier4)")
            print(f"[AUDIO_FILE]{audio}")
            return
        else:
            if not quiet:
                print(f"[✗] 重启后流式重试也失败: {output4[:80]} ({elapsed4:.1f}s)")

    if not quiet:
        print("[错误] 四种模式（含自动重启）均失败，请手动检查TTS服务器")
    else:
        print(f"[ERROR] 四种TTS模式（含自动重启）均失败")
    sys.exit(1)


if __name__ == "__main__":
    main()
