"""
WorkBuddy TTS 并行加速回复工具
策略：智能分句 → 两台服务器并发合成 → 按序合并 WAV → 播放
用法：python tts_reply.py "角色名" "回复文本"
"""
import sys
import os
import re
import io
import json
import wave
import winsound
import urllib.request
import urllib.error
import urllib.parse
import threading
import socket
import struct
from datetime import datetime

# ── 自动切换工作目录到脚本所在目录，兼容任意调用路径和中文路径 ──
_HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(_HERE)

# 强制 stdout 使用 utf-8，避免 Windows GBK 编码报错
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8')

AUDIO_DIR   = r"H:\WorkBuddy\generated_audio"
RESULT_FILE = os.path.join(_HERE, "speak_result.txt")

# ══════════════════════════════════════════════════════════════
# neko api（2026-10-12 上线，新显卡 N 卡）
#   · GPT-SoVITS API v3，本机 9881 端口，服务目录 api_neko/
#   · 走 /api/v2/tts 兼容接口：GET 同步，返回标准单文件 WAV
#   · text_lang=auto 原生多语言识别（旧接口不支持，故仅 neko 保留 auto）
#   · 只有已注册参考音频的角色可用（春原瞬/春原心奈/丹花伊吹）
# ══════════════════════════════════════════════════════════════
# ⚠️ 两台机器都跑 neko，速度差 10 倍（2026-10-12 实测）：
#   · 192.168.31.8  = P104-100 8GB（快，实时率 1.3x）⭐ 主力
#   · 127.0.0.1     = 本机 920MX 2GB（慢，实时率 0.13x）兜底
NEKO_BASE        = "http://192.168.31.8:9881"
NEKO_BASE_ALT    = "http://127.0.0.1:9881"
NEKO_TTS_URL     = NEKO_BASE + "/api/v2/tts"
NEKO_TTS_URL_ALT = NEKO_BASE_ALT + "/api/v2/tts"
NEKO_GROUP       = [NEKO_TTS_URL, NEKO_TTS_URL_ALT]   # 顺序即优先级
NEKO_TIMEOUT_MIN = 120          # neko 最小超时（N卡很快，留足冷启动余量）

# neko 服务器上的参考音频 + 权重 —— 注意路径是**服务器端路径**，不是本机路径！
# ⚠️ v2 接口不接受 voice_id，权重是服务端全局状态，必须用 set_*_weights 显式切换，
#    否则参考音频会跟当前加载的权重对不上（2026-10-15 老师调整命名后新增）
NEKO_VOICES = {
    # 春原瞬 · 国语底（2026-10-15 老师调整：voice_id `shun` = 国语底，作为默认）
    "春原瞬": {
        "voice_id": "shun",
        "gpt_weights": "GPT_weights_v2/youshun-ZH-v2-e15.ckpt",
        "sovits_weights": "SoVITS_weights_v2/youshun-ZH-v2_e8_s1104.pth",
        "ref_audio_path": "api_neko/voices/shun-请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！.wav",
        "prompt_text": "请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！",
        "prompt_lang": "all_zh",
    },
    # 春原瞬 · 日语底（原 `shun`，2026-10-15 更名为 `shun-jp`）
    "春原瞬jp": {
        "voice_id": "shun-jp",
        "gpt_weights": "GPT_weights_v2/youshun-e10.ckpt",
        "sovits_weights": "SoVITS_weights_v2/youshun_e10_s170.pth",
        "ref_audio_path": "api_neko/voices/shun-しゅ、シュンお姉さんはどこに行ったんでしょうね？.wav",
        "prompt_text": "しゅ、シュンお姉さんはどこに行ったんでしょうね？",
        "prompt_lang": "all_ja",
    },
    "春原心奈": {
        "voice_id": "kokona",
        "gpt_weights": "GPT_weights_v2/kokona-v2-e15.ckpt",
        "sovits_weights": "SoVITS_weights_v2/kokona_v2_e24_s312.pth",
        "ref_audio_path": "api_neko/voices/kokona-我是训育支援部梅花园的心奈！ 别，别看我小，我可是正经的教官哦？！.wav",
        "prompt_text": "我是训育支援部梅花园的心奈！ 别，别看我小，我可是正经的教官哦？！",
        "prompt_lang": "all_zh",
    },
    "丹花伊吹": {
        "voice_id": "ibuki",
        "gpt_weights": "GPT_weights_v2/YiChui-e15.ckpt",
        "sovits_weights": "SoVITS_weights_v2/YiChui_e24_s408.pth",
        "ref_audio_path": "api_neko/voices/ibuki-終わったら先生と遊ぼうっと.wav",
        "prompt_text": "終わったら先生と遊ぼうっと",
        "prompt_lang": "all_ja",
    },
}
# 兼容旧角色名（2026-10-12 曾用 "春原瞬zh" 指普通话原声线）
NEKO_VOICES["春原瞬zh"] = NEKO_VOICES["春原瞬"]


def is_neko_url(url):
    """判断是否为 neko api 地址（v3 兼容接口）"""
    return bool(url) and "/api/v2/tts" in url


# ── 服务器分组（每组为一台物理机器，组内任一IP可用即可）──
SERVER_GROUPS = [
    # ⭐ neko api（首选：31.8 的 P104-100 8GB → 本机 2GB 兜底）2026-10-12 上线
    NEKO_GROUP,
    # ── 以下为旧架构（服务已全部下线，暂时注释以省去健康检测的 3s×N 超时等待）──
    # 老家/原生接口恢复后再启用
    # 本地服务器（GPU推理）
    # IP映射：127.0.0.1 = 192.168.31.3（有线）= 192.168.31.5（无线）
    # [
    #     "http://127.0.0.1:9880/tts",
    # ],
    # 广州GPU服务器
    # [
    #     "http://192.168.31.6:9880/tts",
    # ],
    # 广州CPU服务器（速度慢）
    # IP映射：192.168.31.4 = 192.168.31.7（无线网卡）
    # [
    #     "http://192.168.31.4:9880/tts",
    #     "http://192.168.31.7:9880/tts",
    # ],
    # 笔记本（老家，暂时注释）
    # [
    #     "http://192.168.28.3:9880/tts",
    #     "http://192.168.31.5:9880/tts",  # 注意：此IP现在是本机无线网卡
    #     "http://192.168.28.7:9880/tts",
    # ],
    # 华硕主机（老家，暂时注释）
    # [
    #     "http://192.168.31.177:9880/tts",
    #     "http://192.168.28.2:9880/tts",
    #     "http://192.168.28.127:9880/tts",
    # ],
]

# ── 角色配置 ──
ROLES = {
    "可莉": {
        "ref_audio_path": "audio/klee-买东西那天也有一个人帮了开了款式，那个人好像叫.wav",
        "prompt_text": "买东西那天也有一个人帮了开了款式，那个人好像叫",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
    },
    "瑶瑶": {
        "ref_audio_path": "audio/yaoyao-甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？.wav",
        "prompt_text": "甘雨姐姐，你没事吧？要不要喝点水，或者吃点别的什么调节一下？",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
    },
    "纳西妲": {
        "ref_audio_path": "audio/nahida-如果是说踏鞴砂那个神秘事件与倾奇者之类的.wav",
        "prompt_text": "如果是说踏鞴砂那个神秘事件与倾奇者之类的",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
        "speed_factor": 0.85,
    },
    "小猫": {
        "ref_audio_path": "audio/xiaomao-大家好，我是小猫。最近我发现有个人一直盗我视频盈利.wav",
        "prompt_text": "大家好，我是小猫。最近我发现有个人一直盗我视频盈利",
        "prompt_lang": "zh",
        "text_lang": "zh",
        "text_split_method": "cut5",
        "speed_factor": 0.8,
        "top_k": 5,
        "top_p": 1,
        "temperature": 1,
        "repetition_penalty": 1.35,
    },
    "春原瞬": {
        "ref_audio_path": "audio/shun-请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！.wav",
        "prompt_text": "请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！",
        "prompt_lang": "zh",
        "text_lang": "auto",
        "text_split_method": "cut0",
        "top_k": 5,
        "top_p": 1,
        "temperature": 1,
        "repetition_penalty": 1.35,
        "speed_factor": 1.0,
    },
    "春原心奈": {
        "ref_audio_path": "audio/kokona-我是训育支援部梅花园的心奈！ 别，别看我小，我可是正经的教官哦？！.wav",
        "prompt_text": "我是训育支援部梅花园的心奈！ 别，别看我小，我可是正经的教官哦？！",
        "prompt_lang": "zh",
        "text_lang": "auto",
        "text_split_method": "cut0",
        "top_k": 5,
        "top_p": 1,
        "temperature": 1,
        "repetition_penalty": 1.35,
        "speed_factor": 1.0,
    },
}

# ── 推理模式标注剥离（2026-08-05新增）──
# 朗读文本开头常带模式标注如 "(并行)"、"（流式）"，仅用于文字展示，
# 不应被TTS朗读出来。此处自动剥离开头的括号标注（含常见模式关键词才剥离，避免误伤正文）。
MODE_ANNOTATION_RE = re.compile(
    r'^[（(]\s*(?:并行|流式|串行|探针|重启|混读|混合|静默|Tier\s*\d|B方案|回退|自动|GPU|CPU)[^）)]*[）)]\s*'
)

def strip_mode_annotation(text):
    """剥离开头的推理模式标注（如 (并行)、（串行+流式）），返回纯净朗读文本"""
    if not text:
        return text
    return MODE_ANNOTATION_RE.sub('', text, count=1)

# ── 智能分句 ──
def split_sentences(text):
    """
    按中文标点智能分句，保证语序完整、语义完整。
    规则：
      1. 按句末标点（。！？…～）切分
      2. 短句（<8字）尽量与下一句合并，避免碎片化
      3. 长句（>40字）按逗号、分号二次切分
      4. 最终每组不超过50字
    """
    if not text.strip():
        return []

    # 第一步：按句末标点切分
    parts = re.split(r'(?<=[。！？…～\!\?])', text)
    parts = [p.strip() for p in parts if p.strip()]

    # 第二步：短句合并（小于8字的短句合并到下一句）
    merged = []
    buf = ""
    for p in parts:
        buf += p
        if len(buf) >= 8:
            merged.append(buf)
            buf = ""
    if buf:
        if merged:
            merged[-1] += buf
        else:
            merged.append(buf)

    # 第三步：超长句按逗号/分号二次切分
    result = []
    for s in merged:
        if len(s) > 50:
            subs = re.split(r'(?<=[，,；;、])', s)
            subs = [x.strip() for x in subs if x.strip()]
            # 再次合并过短的子句
            sub_buf = ""
            for sub in subs:
                sub_buf += sub
                if len(sub_buf) >= 15:
                    result.append(sub_buf)
                    sub_buf = ""
            if sub_buf:
                if result:
                    result[-1] += sub_buf
                else:
                    result.append(sub_buf)
        else:
            result.append(s)

    return result if result else [text]

# ── 构建 TTS 请求体 ──
def build_payload(role, text, server_url=None, lang=None, streaming_mode=None, no_parallel=False, speed_factor=None):
    """speed_factor: 语速覆盖（1.0=正常，>1快，<1慢），None=用角色默认配置"""
    cfg = ROLES.get(role, ROLES["春原瞬"])
    neko = is_neko_url(server_url)

    # 优先使用传入的 lang 参数
    # 支持 "ja"（正确）和 "j"（旧写法）作为日语参数
    if lang and lang in ("zh", "ja", "j", "en", "auto"):
        text_lang = lang
        # 标准化：将 "j" 转换为 "ja"
        if text_lang == "j":
            text_lang = "ja"
    else:
        # 强制确保 text_lang 不为 None，默认使用 "zh"
        text_lang = cfg.get("text_lang") or "zh"

    # 旧接口不支持 auto，降级为 zh；neko api 原生支持多语言识别，保留 auto（2026-10-12）
    if text_lang == "auto" and not neko:
        text_lang = "zh"

    # 默认使用 neko api（2026-10-12 起为新主力）
    if server_url is None:
        server_url = NEKO_TTS_URL

    payload = {
        "type": "gpt_sovits_v2",
        "text": text,
        "text_lang": text_lang,
        "ref_audio_path": cfg["ref_audio_path"],
        "prompt_text": cfg["prompt_text"],
        "prompt_lang": cfg["prompt_lang"],
        "url": server_url,
        "output_dir": "tmp/",
        "top_k": cfg.get("top_k", 5),
        "top_p": cfg.get("top_p", 1),
        "temperature": cfg.get("temperature", 1),
        "text_split_method": cfg.get("text_split_method", "cut0"),
        "batch_size": 1,
        "batch_threshold": 0.75,
        "split_bucket": True,
        "return_fragment": False,
        "speed_factor": speed_factor if speed_factor is not None else cfg.get("speed_factor", 1.0),
        "streaming_mode": bool(streaming_mode),  # 默认并行模式；--streaming 启用流式备用
        "seed": -1,
        "parallel_infer": not no_parallel,  # --no-parallel 启用串行BERT推理（省显存）
        "repetition_penalty": cfg.get("repetition_penalty", 1.35),
        "aux_ref_audio_paths": cfg.get("aux_ref_audio_paths", []),
    }

    # ── neko api 适配（2026-10-12）──
    if neko:
        nk = NEKO_VOICES.get(role)
        if nk:
            # 参考音频必须换成**服务器端路径**（本机 audio/ 路径服务器不认识）
            payload["ref_audio_path"] = nk["ref_audio_path"]
            payload["prompt_text"]     = nk["prompt_text"]
            payload["prompt_lang"]     = nk["prompt_lang"]
            # neko 的 v2 接口走同步单文件，禁用流式分片（分片客户端还要合并）
            payload["streaming_mode"]  = False
            # 服务端 cut5 智能分句（比 ROLES 里的 cut0 更适合长文本）
            payload["text_split_method"] = "cut5"
            # 权重随音色切换（v2 接口不接受 voice_id，权重是服务端全局状态）
            # 下划线开头 = 私有字段，不会被 NEKO_QUERY_KEYS 白名单发出去
            payload["_voice_id"]       = nk.get("voice_id")
            payload["_gpt_weights"]    = nk.get("gpt_weights")
            payload["_sovits_weights"] = nk.get("sovits_weights")
        else:
            # 该角色在 neko 上没有注册参考音频 → 标记跳过 neko 组
            payload["_neko_unsupported"] = True

    return payload

# ── 快速健康检测（TCP connect，默认1秒超时） ──
def _tcp_alive(url, timeout=0.6):
    """快速 TCP 探测：LAN 内在线主机 <50ms 响应，离线主机会卡满 timeout。
    用于在发起昂贵的合成请求前先排除离线端点（2026-10-12 新增）。"""
    try:
        parsed = urllib.parse.urlparse(url)
        host = parsed.hostname
        port = parsed.port or 9880
        sock = socket.create_connection((host, port), timeout=timeout)
        sock.close()
        return True
    except Exception:
        return False


def is_group_alive(server_group, timeout=1.0):
    """尝试TCP连接组内任一IP，能连上就返回True"""
    for url in server_group:
        try:
            parsed = urllib.parse.urlparse(url)
            host = parsed.hostname
            port = parsed.port or 9880
            sock = socket.create_connection((host, port), timeout=timeout)
            sock.close()
            return True
        except Exception:
            continue
    return False

# ── 动态计算超时时间 ──
def estimate_timeout(text):
    """
    根据文本长度动态估算TTS合成所需时间
    基准：
    - 游戏开启时：约 2-5 it/s，单句可能需要 2-5分钟
    - 游戏关闭时：约 15-30 it/s，单句可能需要 10-30秒
    安全策略：按较长耗时估算 + 充足缓冲
    """
    text_len = len(text.strip())
    
    # 基础超时（网络延迟 + 初始化）
    base_timeout = 15
    
    # 每字符估算：GPU空闲时约 25it/s，20字约需 10-15s
    # 余量充足：每字符 0.5s，20字 → 25s 足够
    per_char_time = 0.5  # 秒/字符
    
    # 计算超时时间
    estimated = base_timeout + (text_len * per_char_time)
    
    # 约束范围：最小30秒，最大300秒（5分钟）
    timeout = max(30, min(int(estimated), 300))
    
    return timeout

# ── 远程重启TTS服务器 ──
def restart_server(server_url):
    """通过 /control 端点远程重启 GPT-SoVITS 服务"""
    try:
        base = server_url.rsplit("/tts", 1)[0]
        ctrl_url = f"{base}/control?command=restart"
        req = urllib.request.Request(ctrl_url)
        urllib.request.urlopen(req, timeout=5)
        print(f"  [重启] {base} → 已发送重启指令")
        return True
    except Exception as e:
        print(f"  [重启] {base} 失败: {e}")
        return False


# ── 流式响应 → 有效WAV重建 ──
def _rebuild_wav(raw_data):
    """
    streaming_mode 返回: 44字节WAV头 + 原始PCM数据
    重建为标准WAV文件
    """
    if len(raw_data) < 44:
        return None
    try:
        sample_rate = struct.unpack_from('<I', raw_data, 24)[0]
        channels = struct.unpack_from('<H', raw_data, 22)[0]
        bits = struct.unpack_from('<H', raw_data, 34)[0]
        pcm = raw_data[44:]

        if len(pcm) == 0:
            return None

        buf = io.BytesIO()
        with wave.open(buf, 'wb') as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(bits // 8)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm)
        return buf.getvalue()
    except Exception as e:
        print(f"    [!] WAV重建失败: {e}")
        return None


# ── neko api：GET 查询参数白名单（v2 兼容接口）──
NEKO_QUERY_KEYS = (
    "text", "text_lang", "ref_audio_path", "prompt_lang", "prompt_text",
    "top_k", "top_p", "temperature", "text_split_method", "batch_size",
    "batch_threshold", "split_bucket", "speed_factor", "fragment_interval",
    "seed", "media_type", "parallel_infer", "repetition_penalty",
    "sample_steps", "super_sampling",
)


def merge_riff_fragments(raw):
    """
    合并多个 RIFF 片段为单个标准 WAV（2026-10-12 新增）。

    neko api 开启 return_fragment 时返回的是若干完整 WAV 首尾相接
    （每段 44 字节头 + PCM），普通播放器只会播第一段（如 3 段 7.98s 的音频
    只能播出第一段 1.54s）。这里抽出所有 data chunk 的 PCM 重新封装成一个 WAV。
    """
    if len(raw) < 44 or raw[:4] != b'RIFF':
        return raw
    try:
        size0 = struct.unpack_from('<I', raw, 4)[0]
        if 8 + size0 >= len(raw):      # 标准单文件，直接返回
            return raw
        sr   = struct.unpack_from('<I', raw, 24)[0]
        ch   = struct.unpack_from('<H', raw, 22)[0]
        bits = struct.unpack_from('<H', raw, 34)[0]
        parts, pos, guard = [], 0, 0
        while pos + 8 <= len(raw) and guard < 10000:
            guard += 1
            cid = raw[pos:pos+4]
            if cid == b'RIFF':         # 新片段起点，跳过 RIFF+size+WAVE
                pos += 12
                continue
            csize = struct.unpack_from('<I', raw, pos + 4)[0]
            if csize > len(raw):
                break
            if cid == b'data':
                parts.append(raw[pos+8:pos+8+csize])
            pos += 8 + csize + (csize % 2)
        pcm = b''.join(parts)
        if not pcm:
            return raw
        print(f"    [neko] 检测到 {len(parts)} 个 RIFF 片段，合并为单文件")
        return (b'RIFF' + struct.pack('<I', 36 + len(pcm)) + b'WAVE' +
                b'fmt ' + struct.pack('<IHHIIHH', 16, 1, ch, sr,
                                      sr * ch * bits // 8, ch * bits // 8, bits) +
                b'data' + struct.pack('<I', len(pcm)) + pcm)
    except Exception as e:
        print(f"    [!] RIFF 合并失败: {e}")
        return raw


# ── neko 权重切换（v2 接口不吃 voice_id，权重是服务端全局状态）──
# 记录每台机器当前加载的权重，避免每次请求都重载（加载一次好几秒）
_NEKO_LOADED = {}


def _neko_ensure_weights(url, payload):
    """
    确保服务器加载了该音色对应的 GPT/SoVITS 权重。
    例：切到「春原瞬jp」时不切权重，就会用国语底的模型唱日语 → 音色错乱。
    返回 True=已就绪（含无需切换），False=切换失败。
    """
    gpt = payload.get("_gpt_weights")
    sov = payload.get("_sovits_weights")
    if not gpt or not sov:
        return True
    base = url.split("/api/")[0]
    if _NEKO_LOADED.get(base) == (gpt, sov):
        return True
    for ep, w in (("set_gpt_weights", gpt), ("set_sovits_weights", sov)):
        try:
            qs = urllib.parse.urlencode({"weights_path": w})
            r = urllib.request.urlopen(f"{base}/api/v2/{ep}?{qs}", timeout=90)
            body = r.read().decode("utf-8", "replace")
            print(f"    [neko] {ep} → {w.split('/')[-1]} ({body[:60].strip()})")
        except Exception as e:
            print(f"    [!] {ep} 失败: {type(e).__name__}: {str(e)[:120]}")
            return False
    _NEKO_LOADED[base] = (gpt, sov)
    return True


def _request_neko(url, payload, timeout=300):
    """
    neko api（GPT-SoVITS v3）：GET /api/v2/tts 同步请求，返回标准单文件 WAV。
    参数完全兼容旧接口，直接复用 payload 里的字段。
    """
    if payload.get("_neko_unsupported"):
        return None, "该角色在 neko 上未注册参考音频（只有春原瞬/春原心奈/丹花伊吹）"
    # 权重对齐：确保服务端加载的是该音色对应的模型
    if not _neko_ensure_weights(url, payload):
        return None, "音色权重切换失败"
    q = {k: payload[k] for k in NEKO_QUERY_KEYS
         if k in payload and payload[k] is not None}
    full = url + "?" + urllib.parse.urlencode(q)
    if os.environ.get("TTS_DEBUG_NEKO"):
        print(f"    [debug] ref={q.get('ref_audio_path')!r}")
        print(f"    [debug] prompt_lang={q.get('prompt_lang')} text_lang={q.get('text_lang')}")
        print(f"    [debug] URL={full}")
        try:
            with open(os.path.join(_HERE, "_neko_last_url.txt"), "w", encoding="utf-8") as _f:
                _f.write(full)
        except Exception:
            pass
    req = urllib.request.Request(full)
    r = urllib.request.urlopen(req, timeout=max(timeout, NEKO_TIMEOUT_MIN))
    raw = r.read()
    if len(raw) <= 100:
        return None, f"数据过小({len(raw)}B)"
    return merge_riff_fragments(raw), None


# ── 向单台服务器组发请求（组内自动切换，支持重试） ──
def request_tts(server_group, payload, timeout=90, retries=2):
    """
    请求 TTS 合成，支持自动重试和故障转移
    - 优先使用第一个服务器
    - 如果失败，自动尝试组内其他服务器
    - 最后可选全局重试机制
    - timeout 可以传入动态计算的值
    - streaming_mode 时实时显示接收进度
    """
    data = json.dumps(payload).encode("utf-8")
    last_error = None
    is_streaming = payload.get("streaming_mode", False)

    # 单次组内尝试
    for attempt in range(retries + 1):
        if attempt > 0:
            print(f"    [重试 {attempt}/{retries}] 重新请求服务器组...")

        for url in server_group:
            try:
                # ── neko 端点快速预探（2026-10-12）──
                # 主机离线时 connect() 会一直卡到超时（实测 3s/超时），
                # 若不拦，_request_neko 的 120s 超时会被白白耗掉才回落本机。
                if is_neko_url(url) and not _tcp_alive(url, 0.6):
                    print(f"    [!] {url} 快速探测离线，跳过")
                    last_error = f"{url} 离线"
                    continue
                # ── neko api 分支：GET 同步，直接拿单文件 WAV（2026-10-12）──
                if is_neko_url(url):
                    t_neko = datetime.now()
                    audio, err = _request_neko(url, payload, timeout)
                    if audio:
                        el = (datetime.now() - t_neko).total_seconds()
                        print(f"    [neko] 接收完成: {len(audio)/1024:.1f}KB ({el:.1f}s)")
                        return audio, url
                    print(f"    [!] {url} {err}")
                    last_error = err
                    continue

                req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
                t_req = datetime.now()

                if is_streaming:
                    # ── 流式模式：取消总超时，仅靠停滞检测保活 ──
                    # 数据在流 = 服务器活着，无论多慢都等
                    # 120秒无任何数据 = 连接已死，放弃
                    STALL_TIMEOUT = 60  # 停滞检测窗口（秒）2026-07-23: 120→60，卡死时更快放弃
                    r = urllib.request.urlopen(req, timeout=STALL_TIMEOUT)
                    chunks = []
                    total = 0
                    last_dot = 0
                    last_data_time = datetime.now()
                    while True:
                        try:
                            chunk = r.read(8192)
                            if not chunk:
                                break
                            chunks.append(chunk)
                            total += len(chunk)
                            last_data_time = datetime.now()  # 收到数据，刷新计时
                            # 每 4KB 输出进度
                            if total - last_dot >= 4096:
                                elapsed = (datetime.now() - t_req).total_seconds()
                                print(f"\r    接收中 {total/1024:.0f}KB ({elapsed:.0f}s)...", end='', flush=True)
                                last_dot = (total // 4096) * 4096
                        except socket.timeout:
                            # 单次 read 超时 = STALL_TIMEOUT 秒没收到数据
                            stall = (datetime.now() - last_data_time).total_seconds()
                            if total > 0:
                                print(f"\r    [!] 停滞 {stall:.0f}s，已收 {total/1024:.0f}KB，判定连接死亡")
                                last_error = f"流式停滞（已收{total/1024:.0f}KB后{stall:.0f}s无数据）"
                            else:
                                print(f"    [!] {url} 流式无响应（{stall:.0f}s无任何数据）")
                                last_error = "流式无响应"
                            break

                    if chunks:
                        full = b''.join(chunks)
                        elapsed = (datetime.now() - t_req).total_seconds()
                        if len(full) > 100:
                            print(f"\r    [流式] 接收完成: {total/1024:.1f}KB ({elapsed:.1f}s)    ")
                            # 流式返回 = WAV头 + 原始PCM → 重建标准WAV
                            audio = _rebuild_wav(full)
                            if audio and len(audio) > 100:
                                return audio, url
                        print(f"    [!] {url} 流式数据无效 ({len(full)} bytes)")
                        last_error = f"流式数据无效"
                    elif not last_error:
                        last_error = "流式无数据"
                else:
                    # ── 非流式模式：原始行为 ──
                    r = urllib.request.urlopen(req, timeout=timeout)
                    audio = r.read()
                    if len(audio) > 100:
                        return audio, url
                    else:
                        print(f"    [!] {url} 返回数据过小 ({len(audio)} bytes)")
                        last_error = f"数据过小"
            except urllib.error.HTTPError as e:
                try:
                    err = e.read().decode(errors='replace')[:80]
                except:
                    err = str(e.code)
                print(f"    [!] {url} HTTP {e.code}: {err}")
                last_error = f"HTTP {e.code}"
            except urllib.error.URLError as e:
                print(f"    [!] {url} 连接失败: {type(e.reason).__name__}")
                last_error = f"连接失败: {type(e.reason).__name__}"
            except socket.timeout:
                print(f"    [!] {url} 请求超时 ({timeout}s)")
                last_error = "请求超时"
            except Exception as e:
                print(f"    [!] {url} {type(e).__name__}: {e}")
                last_error = f"{type(e).__name__}: {e}"
    
    return None, last_error

# ── WAV 字节流合并（保持语序） ──
def merge_wav_bytes(wav_list):
    """将多段 WAV 字节流按顺序合并为一个完整 WAV，零间隙拼接"""
    if not wav_list:
        return None
    if len(wav_list) == 1:
        return wav_list[0]

    frames_list = []
    params = None
    for wav_bytes in wav_list:
        try:
            with wave.open(io.BytesIO(wav_bytes), 'rb') as wf:
                if params is None:
                    params = wf.getparams()
                frames_list.append(wf.readframes(wf.getnframes()))
        except Exception as e:
            print(f"  [!] WAV解析失败: {e}")
            continue

    if not frames_list or params is None:
        return None

    out_buf = io.BytesIO()
    with wave.open(out_buf, 'wb') as wf:
        wf.setparams(params)
        for frames in frames_list:
            wf.writeframes(frames)
    return out_buf.getvalue()

# ── 文件命名 ──
def make_filename(role, text):
    safe = re.sub(r'[\\/:*?"<>|\s]', '', text)[:20]
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{role}-{safe}-{ts}.wav"

# ── 主函数 ──
def tts_reply(role, text, lang=None, streaming=False, no_parallel=False, no_save=False, no_play=False, speed=None):
    # 剥离推理模式标注（如"(并行)"），避免被TTS朗读（2026-08-05新增）
    text = strip_mode_annotation(text)
    print(f"\n{'='*55}")
    print(f"[{role}] {text}")
    print(f"{'='*55}")
    if speed is not None:
        print(f"[语速] speed_factor = {speed}")

    # ── neko api：服务端自带 cut5 分句 + 并行推理 ──
    # 客户端分句会产生 N 个并发请求，被服务端串行处理（实测 3 句 → 30s）
    # 整段提交交给服务端内部并行，效率更高（2026-10-12）
    neko_mode = role in NEKO_VOICES and is_group_alive(NEKO_GROUP, timeout=0.8)
    if neko_mode:
        print("[neko] 整段提交（服务端 cut5 分句 + 并行推理）")
        sentences = [text]
    else:
        sentences = split_sentences(text)
    total = len(sentences)
    print(f"[分句] 共 {total} 句: {sentences}")

    if total == 0:
        return

    t_start = datetime.now()

    # 单句：串行
    if total <= 1:
        print(f"[合成] 串行模式（{total}句）")
        # 健康检测，只用在线服务器
        alive_groups = []
        for i, group in enumerate(SERVER_GROUPS):
            ok = is_group_alive(group)
            print(f"  组{i+1}: {'在线 ✓' if ok else '离线 ✗'} ({group[0].split('/')[2]}...)")
            if ok:
                alive_groups.append(group)
        
        if not alive_groups:
            print("[错误] 所有服务器离线，无法合成")
            return
        
        all_servers = [url for group in alive_groups for url in group]
        wav_list = []
        failed_count = 0
        for i, s in enumerate(sentences):
            payload = build_payload(role, s, all_servers[0], lang=lang, streaming_mode=streaming, no_parallel=no_parallel, speed_factor=speed)
            dyn_timeout = estimate_timeout(s)
            print(f"  [动态超时] 句{i+1}: {len(s)}字 → {dyn_timeout}s")
            audio, info = request_tts(all_servers, payload, timeout=dyn_timeout, retries=2)
            if audio:
                wav_list.append(audio)
                print(f"  [✓] 句{i+1}/{total} 成功 ({len(audio)} bytes) <- {info.split('/')[2] if '/' in info else info}")
            else:
                failed_count += 1
                print(f"  [✗] 句{i+1}/{total} 失败: {info}")
        
        if not wav_list:
            print("[错误] 所有片段合成失败！")
            return
        
        if failed_count > 0:
            print(f"[警告] {failed_count}/{total} 句合成失败，音频将不完整！")
        
        wav_data = merge_wav_bytes(wav_list) if len(wav_list) > 1 else wav_list[0]
    elif no_parallel:
        # --no-parallel 模式：多句也走串行处理（2026-07-23新增）
        # 原因：no_parallel=省显存保活模式，不应该用多线程并发请求
        # 多线程并发可能冲突 + 远程服务器不可靠时浪费时间
        # 串行一句一句来，只用本地服务器，稳定可靠
        print(f"[合成] 串行模式（{total}句，--no-parallel）")
        alive_groups = []
        for i, group in enumerate(SERVER_GROUPS):
            ok = is_group_alive(group)
            print(f"  组{i+1}: {'在线 ✓' if ok else '离线 ✗'} ({group[0].split('/')[2]}...)")
            if ok:
                alive_groups.append(group)
        
        if not alive_groups:
            print("[错误] 所有服务器离线，无法合成")
            return
        
        all_servers = [url for group in alive_groups for url in group]
        wav_list = []
        failed_count = 0
        for i, s in enumerate(sentences):
            payload = build_payload(role, s, all_servers[0], lang=lang, streaming_mode=streaming, no_parallel=no_parallel, speed_factor=speed)
            dyn_timeout = estimate_timeout(s)
            print(f"  [动态超时] 句{i+1}: {len(s)}字 → {dyn_timeout}s")
            audio, info = request_tts(all_servers, payload, timeout=dyn_timeout, retries=2)
            if audio:
                wav_list.append(audio)
                print(f"  [✓] 句{i+1}/{total} 成功 ({len(audio)} bytes) <- {info.split('/')[2] if '/' in info else info}")
            else:
                failed_count += 1
                print(f"  [✗] 句{i+1}/{total} 失败: {info}")
        
        if not wav_list:
            print("[错误] 所有片段合成失败！")
            return
        
        if failed_count > 0:
            print(f"[警告] {failed_count}/{total} 句合成失败，音频将不完整！")
        
        wav_data = merge_wav_bytes(wav_list) if len(wav_list) > 1 else wav_list[0]
    else:
        # 2句及以上：并发模式
        # 先做健康检测，过滤掉不在线的服务器组
        print(f"[健康检测] 检测 {len(SERVER_GROUPS)} 个服务器组...")
        alive_groups = []
        for i, group in enumerate(SERVER_GROUPS):
            ok = is_group_alive(group)
            print(f"  组{i+1}: {'在线 ✓' if ok else '离线 ✗'} ({group[0].split('/')[2]}...)")
            if ok:
                alive_groups.append(group)

        if not alive_groups:
            print("[错误] 所有服务器离线，无法合成")
            return

        N_MACHINES = len(alive_groups)
        print(f"[合成] 并行模式（{total}句 × {N_MACHINES}台在线服务器）")
        results = [None] * total
        lock = threading.Lock()

        def worker(idx, sentence, group, attempt=1):
            payload = build_payload(role, sentence, group[0], lang=lang, streaming_mode=streaming, no_parallel=no_parallel, speed_factor=speed)
            dyn_timeout = estimate_timeout(sentence)
            if attempt == 1:
                print(f"  [动态超时] 句{idx+1}: {len(sentence)}字 → {dyn_timeout}s")
            audio, info = request_tts(group, payload, timeout=dyn_timeout, retries=1)
            with lock:
                if audio:
                    results[idx] = audio
                    print(f"  [✓] 句{idx+1}/{total} 成功 ({len(audio)} bytes) <- {info.split('/')[2] if '/' in info else info}")
                else:
                    print(f"  [✗] 句{idx+1}/{total} 失败 (第{attempt}次): {info}")

        # 按轮次分批处理，每轮最多 N_MACHINES 句并行
        for batch_start in range(0, total, N_MACHINES):
            batch = sentences[batch_start:batch_start + N_MACHINES]
            threads = []
            for j, s in enumerate(batch):
                idx = batch_start + j
                group = alive_groups[j % N_MACHINES]
                t = threading.Thread(target=worker, args=(idx, s, group, 1))
                threads.append(t)
                t.start()
            for t in threads:
                t.join()

        # 失败的句子换到本地服务器重试（2026-07-23：优先本地，避免远程服务器RemoteDisconnected）
        failed_indices = [i for i, r in enumerate(results) if r is None]
        if failed_indices:
            print(f"[重试] {len(failed_indices)} 个失败句子换到本地服务器重试...")
            retry_threads = []
            for i in failed_indices:
                s = sentences[i]
                # 优先用本地服务器（组1）重试，避免远程服务器连接问题
                fallback_group = alive_groups[0]
                t = threading.Thread(target=worker, args=(i, s, fallback_group, 2))
                retry_threads.append(t)
                t.start()
            for t in retry_threads:
                t.join()

        # 统计最终结果
        valid = [r for r in results if r is not None]
        still_failed = len([r for r in results if r is None])
        
        if still_failed > 0:
            print(f"[警告] {still_failed}/{total} 句仍然失败，音频将不完整！")
        
        if not valid:
            print("[错误] 全部片段合成失败")
            return

        wav_data = merge_wav_bytes(valid)
        if not wav_data:
            print("[错误] WAV 合并失败")
            return

    t_gen = (datetime.now() - t_start).total_seconds()

    # 保存文件
    if not no_save:
        os.makedirs(AUDIO_DIR, exist_ok=True)
        out_path = os.path.join(AUDIO_DIR, make_filename(role, text))
        with open(out_path, "wb") as f:
            f.write(wav_data)

        # 获取时长
        with wave.open(io.BytesIO(wav_data), 'rb') as wf:
            duration = wf.getnframes() / wf.getframerate()

        print(f"[完成] 生成耗时 {t_gen:.2f}s | 音频时长 {duration:.2f}s | 加速比 {duration/t_gen:.1f}x")
        print(f"[保存] {os.path.basename(out_path)}")
    else:
        print(f"[完成] 生成耗时 {t_gen:.2f}s | 不保存 (--no-save)")

    # 写摘要文件，供 AI 调用时快速读取结果
    try:
        with open(RESULT_FILE, "w", encoding="utf-8") as f:
            f.write(f"{t_gen:.2f}s,{duration/t_gen:.1f}x\n")
    except Exception:
        pass

    # 播放（no_save 时跳过，因为 out_path 不存在）
    if not no_play and not no_save:
        winsound.PlaySound(out_path, winsound.SND_FILENAME)

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    lang = None
    speed = None
    # 支持 --lang=j 和 --lang j 两种格式
    for i, a in enumerate(sys.argv):
        if a.startswith("--lang="):
            lang = a.split("=", 1)[1]
            break
        elif a == "--lang" and i + 1 < len(sys.argv):
            lang = sys.argv[i + 1]
            break
    # --speed=1.2 或 --speed 1.2（2026-08-05新增，语速控制）
    for i, a in enumerate(sys.argv):
        if a.startswith("--speed="):
            try:
                speed = float(a.split("=", 1)[1])
            except ValueError:
                pass
            break
        elif a == "--speed" and i + 1 < len(sys.argv):
            try:
                speed = float(sys.argv[i + 1])
            except ValueError:
                pass
            break
    
    verbose = "--verbose" in sys.argv
    do_restart = "--restart" in sys.argv
    use_streaming = "--streaming" in sys.argv
    no_parallel = "--no-parallel" in sys.argv
    no_save = "--no-save" in sys.argv
    no_play = "--no-play" in sys.argv

    # ── 远程重启模式 ──
    if do_restart:
        print("[远程重启] 向所有服务器发送重启指令...")
        for group in SERVER_GROUPS:
            for url in group:
                restart_server(url)
        sys.exit(0)

    if len(args) < 2:
        print("用法: python tts_reply.py <角色名> <文本> [--verbose] [--restart] [--streaming] [--no-parallel] [--no-save] [--no-play] [--speed X]")
        print("  --streaming   : 启用流式模式（备用，默认并行模式）")
        print("  --no-parallel : 串行BERT推理（省显存，终极保活，速度慢2.5x）")
        print("  --no-save     : 不保存WAV文件（仅测试服务器存活时使用）")
        print("  --no-play     : 不自动播放（混读合并时中间段使用）")
        print("  --speed X     : 语速覆盖（1.0=正常，>1快，<1慢；默认用角色配置）")
        sys.exit(1)

    if verbose:
        # 详细模式：完整日志输出，适合调试
        tts_reply(args[0], args[1], lang=lang, streaming=use_streaming, no_parallel=no_parallel, no_save=no_save, no_play=no_play, speed=speed)
    else:
        # 默认静默模式：日志写文件，只输出一行摘要
        log_path = os.path.join(_HERE, "speak_log.txt")
        with open(log_path, "w", encoding="utf-8") as _log:
            _orig_stdout, _orig_stderr = sys.stdout, sys.stderr
            sys.stdout = _log
            sys.stderr = _log
            try:
                tts_reply(args[0], args[1], lang=lang, streaming=use_streaming, no_parallel=no_parallel, no_save=no_save, no_play=no_play, speed=speed)
            finally:
                sys.stdout = _orig_stdout
                sys.stderr = _orig_stderr
        try:
            with open(RESULT_FILE, encoding="utf-8") as f:
                t, r = f.read().strip().split(",")
            mode = "流式" if use_streaming else "并行"
            print(f"（{mode}模式，生成耗时 {t}，加速比 {r}）")
        except Exception:
            pass
