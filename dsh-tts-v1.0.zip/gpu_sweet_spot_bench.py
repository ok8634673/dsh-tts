"""
GPU 利用率甜点区间压测脚本
目标：找到 920MX 上 GPT-SoVITS 并行推理的 GPU 利用率拐点
方法：渐进式增加并发请求数，同时采样 GPU 利用率，测量延迟变化

用法：
  python gpu_sweet_spot_bench.py              # 完整压测（1~8 并发）
  python gpu_sweet_spot_bench.py --max 5      # 只测到 5 并发
  python gpu_sweet_spot_bench.py --quick      # 快速模式（1~4 并发，每级2轮）
"""
import sys
import os
import json
import time
import threading
import subprocess
import urllib.request
import urllib.error
import socket
from collections import defaultdict
from datetime import datetime

# ── 路径 ──
_HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(_HERE)

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# ── 配置 ──
TTS_URL = "http://127.0.0.1:9880/tts"
SERVER_HOST = "127.0.0.1"
SERVER_PORT = 9880

# 压测用文本（固定，10字左右，代表典型短句）
TEST_TEXTS = [
    "老师你好，今天天气真不错呢。",
    "梅花园的大家都很有精神呢！",
    "即使身体变小了，心态不能变。",
    "这个甜点看起来好好吃的样子。",
    "训练计划已经制定好了，请过目。",
    "心奈她又偷偷跑出去玩了。",
    "基沃托斯的和平由我们来守护。",
    "教官的工作虽然辛苦但很充实。",
]

ROLE_CONFIG = {
    "ref_audio_path": "audio/shun-请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！.wav",
    "prompt_text": "请，不要把我当做小孩子……！即使身体变小了，心理层面上我还是大家的姐姐哦！",
    "prompt_lang": "zh",
    "text_lang": "zh",
    "text_split_method": "cut0",
    "top_k": 5,
    "top_p": 1,
    "temperature": 1,
    "repetition_penalty": 1.35,
    "speed_factor": 1.0,
}

# ── GPU 监控 ──
class GPUMonitor:
    """后台线程持续采样 GPU 利用率"""

    def __init__(self, interval=0.5):
        self.interval = interval
        self.samples = []
        self._running = False
        self._thread = None

    def _query_gpu(self):
        """用 nvidia-smi 查询 GPU 利用率"""
        try:
            result = subprocess.run(
                ["nvidia-smi",
                 "--query-gpu=utilization.gpu,memory.used,temperature.gpu",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                parts = result.stdout.strip().split(',')
                if len(parts) >= 3:
                    return {
                        'gpu_util': int(parts[0].strip()),
                        'mem_used': int(parts[1].strip()),
                        'temp': int(parts[2].strip()),
                        'ts': time.time()
                    }
        except Exception:
            pass
        return None

    def start(self):
        self._running = True
        self.samples = []
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def _loop(self):
        while self._running:
            sample = self._query_gpu()
            if sample:
                self.samples.append(sample)
            time.sleep(self.interval)

    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=3)

    def get_stats(self):
        """返回采样期间的统计"""
        if not self.samples:
            return {'avg': 0, 'max': 0, 'min': 0, 'count': 0}

        utils = [s['gpu_util'] for s in self.samples]
        mems = [s['mem_used'] for s in self.samples]
        return {
            'avg': sum(utils) / len(utils),
            'max': max(utils),
            'min': min(utils),
            'mem_avg': sum(mems) / len(mems),
            'count': len(utils),
        }


# ── 服务器健康检查 ──
def wait_for_server(timeout=120):
    """等待 TTS 服务器上线"""
    print("[等待] 检测 TTS 服务器 (127.0.0.1:9880)...")
    start = time.time()
    while time.time() - start < timeout:
        try:
            sock = socket.create_connection((SERVER_HOST, SERVER_PORT), timeout=3)
            sock.close()
            print(f"[等待] 服务器已上线 ({time.time()-start:.1f}s)")
            return True
        except Exception:
            time.sleep(2)
    print("[等待] 服务器超时未上线")
    return False


def send_tts_request(text, timeout=120):
    """发送单个 TTS 请求，返回 (success, latency, audio_size)"""
    payload = {
        "type": "gpt_sovits_v2",
        "text": text,
        "text_lang": ROLE_CONFIG["text_lang"],
        "ref_audio_path": ROLE_CONFIG["ref_audio_path"],
        "prompt_text": ROLE_CONFIG["prompt_text"],
        "prompt_lang": ROLE_CONFIG["prompt_lang"],
        "url": TTS_URL,
        "output_dir": "tmp/",
        "top_k": ROLE_CONFIG["top_k"],
        "top_p": ROLE_CONFIG["top_p"],
        "temperature": ROLE_CONFIG["temperature"],
        "text_split_method": ROLE_CONFIG["text_split_method"],
        "batch_size": 1,
        "batch_threshold": 0.75,
        "split_bucket": True,
        "return_fragment": False,
        "speed_factor": ROLE_CONFIG["speed_factor"],
        "streaming_mode": False,
        "seed": -1,
        "parallel_infer": True,
        "repetition_penalty": ROLE_CONFIG["repetition_penalty"],
        "aux_ref_audio_paths": [],
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(TTS_URL, data=data, headers={"Content-Type": "application/json"})
    t0 = time.time()
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        audio = resp.read()
        latency = time.time() - t0
        if len(audio) > 100:
            return True, latency, len(audio)
        else:
            return False, latency, 0
    except Exception as e:
        latency = time.time() - t0
        return False, latency, 0


# ── 并发压测 ──
def bench_concurrency(n_concurrent, round_num=1):
    """
    在指定并发级别下进行压测
    返回: {
        'concurrency': n,
        'round': r,
        'latencies': [float],
        'total_time': float,
        'success_count': int,
        'fail_count': int,
        'gpu_stats': {...},
    }
    """
    texts = TEST_TEXTS[:n_concurrent]
    results = [None] * n_concurrent
    threads = []

    # 启动 GPU 监控
    monitor = GPUMonitor(interval=0.3)
    monitor.start()

    t_start = time.time()

    def worker(idx, text):
        success, latency, size = send_tts_request(text, timeout=180)
        results[idx] = {
            'success': success,
            'latency': latency,
            'size': size,
            'text': text,
        }

    for i, text in enumerate(texts):
        t = threading.Thread(target=worker, args=(i, text))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    t_end = time.time()
    monitor.stop()

    latencies = [r['latency'] for r in results if r and r['success']]
    successes = sum(1 for r in results if r and r['success'])
    fails = n_concurrent - successes

    gpu_stats = monitor.get_stats()

    return {
        'concurrency': n_concurrent,
        'round': round_num,
        'latencies': latencies,
        'avg_latency': sum(latencies) / len(latencies) if latencies else 0,
        'max_latency': max(latencies) if latencies else 0,
        'min_latency': min(latencies) if latencies else 0,
        'total_time': t_end - t_start,
        'success_count': successes,
        'fail_count': fails,
        'throughput': successes / (t_end - t_start) if (t_end - t_start) > 0 else 0,
        'gpu_avg': gpu_stats['avg'],
        'gpu_max': gpu_stats['max'],
        'gpu_min': gpu_stats['min'],
        'gpu_mem_avg': gpu_stats.get('mem_avg', 0),
        'gpu_samples': gpu_stats['count'],
    }


# ── 主函数 ──
def main():
    import argparse
    parser = argparse.ArgumentParser(description="GPU 利用率甜点区间压测")
    parser.add_argument("--max", type=int, default=8, help="最大并发数 (默认8)")
    parser.add_argument("--rounds", type=int, default=3, help="每个级别重复轮数 (默认3)")
    parser.add_argument("--quick", action="store_true", help="快速模式 (max=4, rounds=2)")
    parser.add_argument("--warmup", action="store_true", default=True, help="预热请求 (默认开启)")
    args = parser.parse_args()

    if args.quick:
        args.max = min(args.max, 4)
        args.rounds = min(args.rounds, 2)

    print("=" * 60)
    print("  GPU 利用率甜点区间压测")
    print(f"  GPU: NVIDIA GeForce 920MX (2GB VRAM)")
    print(f"  Server: {TTS_URL}")
    print(f"  并发级别: 1 ~ {args.max}, 每级 {args.rounds} 轮")
    print("=" * 60)

    # 等待服务器
    if not wait_for_server(timeout=120):
        print("[错误] TTS 服务器不可用，退出")
        sys.exit(1)

    # 预热（让模型完全加载到 GPU）
    if args.warmup:
        print("\n[预热] 发送预热请求...")
        for i in range(2):
            success, latency, size = send_tts_request("预热测试", timeout=120)
            status = "OK" if success else "FAIL"
            print(f"  预热 {i+1}: {status} ({latency:.1f}s, {size} bytes)")
            if not success:
                print("  [警告] 预热失败，服务器可能不稳定")
            time.sleep(1)

    # 基准延迟（单请求，无并发）
    print("\n[基准] 测量单请求延迟（3次取平均）...")
    base_latencies = []
    for i in range(3):
        success, latency, size = send_tts_request(TEST_TEXTS[i], timeout=120)
        if success:
            base_latencies.append(latency)
            print(f"  基准 {i+1}: {latency:.2f}s ({size} bytes)")
        time.sleep(0.5)

    base_avg = sum(base_latencies) / len(base_latencies) if base_latencies else 0
    print(f"  基准平均延迟: {base_avg:.2f}s")

    # 渐进式压测
    all_results = []
    concurrency_levels = list(range(1, args.max + 1))

    print(f"\n{'='*60}")
    print("  开始渐进式并发压测")
    print(f"{'='*60}")

    for n in concurrency_levels:
        for r in range(1, args.rounds + 1):
            print(f"\n[压测] 并发={n}, 轮次={r}/{args.rounds}")
            print(f"  发送 {n} 个并发请求...")

            result = bench_concurrency(n, r)
            all_results.append(result)

            print(f"  结果: 成功={result['success_count']}/{n}, "
                  f"平均延迟={result['avg_latency']:.2f}s, "
                  f"最大延迟={result['max_latency']:.2f}s, "
                  f"总耗时={result['total_time']:.2f}s, "
                  f"吞吐={result['throughput']:.2f} req/s")
            print(f"  GPU: avg={result['gpu_avg']:.0f}%, "
                  f"max={result['gpu_max']}%, "
                  f"min={result['gpu_min']}%, "
                  f"显存={result['gpu_mem_avg']:.0f}MiB "
                  f"({result['gpu_samples']}样本)")

            # 如果失败率超过50%，停止增加并发
            if result['fail_count'] > n / 2:
                print(f"\n  [!] 失败率 > 50%，停止增加并发")
                break

            # 请求间冷却
            time.sleep(2)

        # 如果上一级别失败率高，停止
        last = all_results[-1]
        if last['fail_count'] > last['concurrency'] / 2:
            break

    # ── 汇总分析 ──
    print(f"\n{'='*60}")
    print("  压测结果汇总")
    print(f"{'='*60}")

    # 按并发级别聚合
    by_level = defaultdict(list)
    for r in all_results:
        by_level[r['concurrency']].append(r)

    print(f"\n{'并发':>4} | {'平均延迟':>8} | {'最大延迟':>8} | {'吞吐':>8} | "
          f"{'GPU avg':>7} | {'GPU max':>7} | {'成功率':>6} | {'降速比':>6}")
    print("-" * 80)

    sweet_spot = None
    degradation_point = None

    for n in sorted(by_level.keys()):
        rounds = by_level[n]
        avg_lat = sum(r['avg_latency'] for r in rounds) / len(rounds)
        max_lat = sum(r['max_latency'] for r in rounds) / len(rounds)
        avg_thr = sum(r['throughput'] for r in rounds) / len(rounds)
        avg_gpu = sum(r['gpu_avg'] for r in rounds) / len(rounds)
        max_gpu = sum(r['gpu_max'] for r in rounds) / len(rounds)
        total_succ = sum(r['success_count'] for r in rounds)
        total_req = sum(r['concurrency'] for r in rounds)
        success_rate = total_succ / total_req * 100 if total_req > 0 else 0

        # 降速比 = 当前平均延迟 / 基准延迟
        slowdown = avg_lat / base_avg if base_avg > 0 else 0

        print(f"{n:>4} | {avg_lat:>7.2f}s | {max_lat:>7.2f}s | {avg_thr:>6.2f}/s | "
              f"{avg_gpu:>6.0f}% | {max_gpu:>6.0f}% | {success_rate:>5.0f}% | {slowdown:>5.1f}x")

        # 检测降速拐点
        if degradation_point is None and slowdown > 1.5 and n > 1:
            degradation_point = {
                'concurrency': n,
                'gpu_util': avg_gpu,
                'slowdown': slowdown,
            }

        # 甜点区间 = 吞吐量最高且降速不超过1.5x
        if slowdown <= 1.5:
            sweet_spot = {
                'concurrency': n,
                'gpu_util': avg_gpu,
                'throughput': avg_thr,
                'slowdown': slowdown,
            }

    # ── 结论 ──
    print(f"\n{'='*60}")
    print("  分析结论")
    print(f"{'='*60}")

    print(f"\n  基准延迟（单请求）: {base_avg:.2f}s")

    if sweet_spot:
        print(f"\n  [甜点区间]")
        print(f"    最大推荐并发: {sweet_spot['concurrency']}")
        print(f"    GPU 利用率: ~{sweet_spot['gpu_util']:.0f}%")
        print(f"    吞吐量: {sweet_spot['throughput']:.2f} req/s")
        print(f"    降速比: {sweet_spot['slowdown']:.1f}x")

    if degradation_point:
        print(f"\n  [降速拐点]")
        print(f"    并发数: {degradation_point['concurrency']}")
        print(f"    GPU 利用率: ~{degradation_point['gpu_util']:.0f}%")
        print(f"    降速比: {degradation_point['slowdown']:.1f}x")
        print(f"    建议: GPU 利用率超过 {degradation_point['gpu_util']:.0f}% 时切换流式模式")
    else:
        print(f"\n  [降速拐点] 未检测到明显降速（所有级别降速比 < 1.5x）")

    # ── 保存结果 ──
    report = {
        'timestamp': datetime.now().isoformat(),
        'gpu': 'NVIDIA GeForce 920MX (2GB)',
        'server': TTS_URL,
        'base_latency': base_avg,
        'sweet_spot': sweet_spot,
        'degradation_point': degradation_point,
        'results': all_results,
    }

    report_path = os.path.join(_HERE, "gpu_bench_report.json")
    with open(report_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"\n  报告已保存: {report_path}")


if __name__ == "__main__":
    main()
