@echo off
rem ===== DSH TTS launcher (ASCII only: avoid cmd codepage issues) =====
chcp 65001 >nul
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1

where python >nul 2>nul
if errorlevel 1 (
  echo [ERROR] python not found in PATH
  pause
  exit /b 1
)

if "%~1"=="" (
  echo Usage:
  echo   speak.bat --status                          show server / health
  echo   speak.bat --list                            list voices
  echo   speak.bat --play "text"                     speak with default voice shun
  echo   speak.bat "text"                            same, without playback
  echo   speak.bat shun "text" --play                pick voice ^(gsv / GPU^)
  echo   speak.bat --serial "long text"              serial infer ^(2GB VRAM safe^)
  echo   speak.bat --base http://192.168.28.7:9881 "text"   force a NIC
  echo.
  echo Default voice: shun ^(gsv backend, GPU accelerated^).
  echo Never use *-onnx: CPU inference, poor timbre.
  echo Auto-discover: guangzhou 192.168.31.8 / home 192.168.28.6 wired, 192.168.28.7 wifi.
  echo Output: .\generated_audio\
  echo.
  exit /b 0
)

python "%~dp0say.py" %*
set ERR=%errorlevel%
if not "%ERR%"=="0" pause
exit /b %ERR%
