"""
WorkBuddy TTS 中日混读包装器
用法：python tts_mixed.py "角色名" "混合文本" [--quiet]

原理：
  GPT-SoVITS 不能在同一次推理中混读中日文（参考音频语言固定）。
  本脚本将混合文本按语言分段，分别用对应语言模式推理，然后合并为一个WAV。

  - 含假名（ひらがな/カタカナ）的句子 → --lang ja
  - 纯汉字+标点的句子 → 默认中文

示例：
  python tts_mixed.py 春原瞬 "先生、おはよう！今天要去萤火虫漫展对吧？頑張ってね！"
  → 分3段：[ja]先生、おはよう！ [zh]今天要去萤火虫漫展对吧？ [ja]頑張ってね！

2026-07-17 新增
"""
import sys
import os
import re
import subprocess
import time
import wave
import shutil
import winsound
from datetime import datetime

# ── 路径配置 ──
_HERE = os.path.dirname(os.path.abspath(__file__))
TTS_AUTO = os.path.join(_HERE, "tts_auto.py")
AUDIO_DIR = r"H:\WorkBuddy\generated_audio"

# ── 按语言语速微调（2026-08-05新增）──
# 不同语言推理引擎的基准语速不同，导致混读拼接后听感不匹配。
# 用 speed_factor 微调各语言段：>1 加快，<1 减慢，1.0=引擎默认。
# 命令行可用 --speed-ja X --speed-zh Y --speed-en X 覆盖；--speed X 则全部语言统一。
LANG_SPEED = {
    "ja": 1.0,   # 日语段默认（如「せんせい！」）
    "zh": 1.0,   # 中文段默认
    "en": 1.0,   # 英文段默认
}

# ── 推理模式标注剥离（2026-08-05新增，与 tts_reply.py 保持一致）──
MODE_ANNOTATION_RE = re.compile(
    r'^[（(]\s*(?:并行|流式|串行|探针|重启|混读|混合|静默|Tier\s*\d|B方案|回退|自动|GPU|CPU)[^）)]*[）)]\s*'
)

def strip_mode_annotation(text):
    """剥离开头的推理模式标注（如 (混读)），返回纯净朗读文本"""
    if not text:
        return text
    return MODE_ANNOTATION_RE.sub('', text, count=1)


def split_sentences(text):
    """按句末标点分句（不在逗号处断开，避免「先生、おはよう！」被拆成两段）"""
    parts = re.split(r'([！？。！？\?\.]+)', text)
    sentences = []
    for i in range(0, len(parts) - 1, 2):
        s = parts[i] + parts[i + 1]
        if s.strip():
            sentences.append(s)
    if parts[-1].strip():
        sentences.append(parts[-1])
    return sentences


def detect_language(sentence):
    """
    检测句子语言（2026-08-05 扩展支持英文段）：
      - 含假名（ひらがな/カタカナ）→ ja
      - 含中文字符 → zh
      - 纯字母且占比>50%（如 Sensei）→ en
      - 其他（纯标点/数字）→ zh
    优先级：ja > zh > en，避免"今天玩BA吗"这类中英混句被误拆为en
    """
    has_ja = False
    has_zh = False
    letter_count = 0
    total = 0
    for char in sentence:
        total += 1
        if ('\u3040' <= char <= '\u309F') or ('\u30A0' <= char <= '\u30FF'):
            has_ja = True
        elif '\u4e00' <= char <= '\u9FFF':
            has_zh = True
        elif ('A' <= char <= 'Z') or ('a' <= char <= 'z'):
            letter_count += 1
    if has_ja:
        return 'ja'
    if has_zh:
        return 'zh'
    if letter_count > 0 and letter_count / max(total, 1) > 0.5:
        return 'en'
    return 'zh'


def split_by_language(text):
    """将混合文本按语言分段，合并相邻同语言句子"""
    sentences = split_sentences(text)
    if not sentences:
        return [('zh', text)]

    segments = []
    for sent in sentences:
        lang = detect_language(sent)
        if segments and segments[-1][0] == lang:
            segments[-1] = (lang, segments[-1][1] + sent)
        else:
            segments.append((lang, sent))
    return segments


def run_segment(role, text, lang, quiet=True, speed=None):
    """调用 tts_auto.py 生成单段音频，返回音频路径（不自动播放）
    speed: 语速覆盖（1.0=正常，>1快，<1慢），None=引擎默认"""
    cmd = [sys.executable, TTS_AUTO, role, text]
    if lang == 'ja':
        cmd.extend(['--lang', 'ja'])
    elif lang == 'en':
        cmd.extend(['--lang', 'en'])
    if speed is not None:
        cmd.extend(['--speed', str(speed)])
    if quiet:
        cmd.append('--quiet')
    cmd.append('--no-play')  # 中间段不播放，合并后才播

    result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    output = result.stdout

    # 解析 [AUDIO_FILE]path
    audio_path = None
    for line in output.strip().split('\n'):
        if line.startswith('[AUDIO_FILE]'):
            audio_path = line.replace('[AUDIO_FILE]', '').strip()
            break

    return audio_path, output


def merge_wavs(wav_paths, output_path):
    """合并多个WAV文件为一个"""
    with wave.open(output_path, 'wb') as out_wav:
        for i, path in enumerate(wav_paths):
            with wave.open(path, 'rb') as in_wav:
                if i == 0:
                    out_wav.setparams(in_wav.getparams())
                out_wav.writeframes(in_wav.readframes(in_wav.getnframes()))


def make_filename(role, text):
    safe = re.sub(r'[\\/:*?"<>|\s]', '', text)[:20]
    ts = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"{role}-{safe}-{ts}.wav"


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    quiet = "--quiet" in sys.argv

    if len(args) < 2:
        print("用法: python tts_mixed.py <角色名> <混合文本> [--quiet] [--speed X] [--speed-ja X] [--speed-zh X] [--speed-en X]")
        print("  --quiet     : 精简输出")
        print("  --speed X   : 全部语言统一语速（1.0=正常，>1快，<1慢）")
        print("  --speed-ja X: 只调日语段语速（如 --speed-ja 1.15）")
        print("  --speed-zh X: 只调中文段语速")
        print("  --speed-en X: 只调英文段语速")
        sys.exit(1)

    role, text = args[0], args[1]
    # 剥离模式标注（如"(混读)"），分段与文件名均不含标注（2026-08-05新增）
    text = strip_mode_annotation(text)
    t0 = time.time()

    # ── 语速解析（2026-08-05新增：按语言微调，解决混读语速不匹配）──
    speed_map = dict(LANG_SPEED)  # 复制默认
    for i, a in enumerate(sys.argv):
        if a.startswith("--speed-"):
            try:
                lang_key = a.split("--speed-", 1)[1].split("=", 1)[0]  # ja/zh/en
                if "=" in a:
                    val = float(a.split("=", 1)[1])
                else:
                    val = float(sys.argv[i + 1])
                if lang_key in speed_map:
                    speed_map[lang_key] = val
            except (ValueError, IndexError):
                pass
        elif a == "--speed" and i + 1 < len(sys.argv):
            try:
                val = float(sys.argv[i + 1])
                speed_map = {k: val for k in speed_map}
            except ValueError:
                pass

    # 分段
    segments = split_by_language(text)

    if len(segments) == 1:
        # 单语言，直接走 tts_auto.py（但通过mixed调用，仍然播放）
        lang = segments[0][0]
        # 单语言不需要 --no-play，直接播放
        cmd = [sys.executable, TTS_AUTO, role, text]
        if lang == 'ja':
            cmd.extend(['--lang', 'ja'])
        elif lang == 'en':
            cmd.extend(['--lang', 'en'])
        spd = speed_map.get(lang)
        if spd is not None and spd != 1.0:
            cmd.extend(['--speed', str(spd)])
        if quiet:
            cmd.append('--quiet')
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        output = result.stdout
        audio_path = None
        for line in output.strip().split('\n'):
            if line.startswith('[AUDIO_FILE]'):
                audio_path = line.replace('[AUDIO_FILE]', '').strip()
            print(line)
        if not audio_path:
            print("[ERROR] TTS生成失败")
            sys.exit(1)
        return

    # 多语言混合
    if not quiet:
        print(f"[混读] 检测到 {len(segments)} 段:")
        for i, (lang, seg) in enumerate(segments):
            print(f"  [{i+1}] {lang}: {seg}")
        print()

    # 逐段生成
    wav_paths = []
    for i, (lang, seg) in enumerate(segments):
        if not quiet:
            spd_note = f" (语速{speed_map.get(lang, 1.0)})" if speed_map.get(lang, 1.0) != 1.0 else ""
            print(f"[混读 {i+1}/{len(segments)}] {lang}{spd_note} → \"{seg}\"")
        audio_path, output = run_segment(role, seg, lang, quiet=True, speed=speed_map.get(lang))
        if audio_path and os.path.exists(audio_path):
            wav_paths.append(audio_path)
            if not quiet:
                print(f"  ✓ {os.path.basename(audio_path)}")
        else:
            if not quiet:
                print(f"  ✗ 生成失败")
            print(f"[ERROR] 第{i+1}段TTS生成失败")
            sys.exit(1)

    # 合并
    merged_name = make_filename(role, text)
    merged_path = os.path.join(AUDIO_DIR, merged_name)

    if len(wav_paths) == 1:
        # 只有一段（理论上不会走到这里）
        shutil.copy2(wav_paths[0], merged_path)
    else:
        merge_wavs(wav_paths, merged_path)

    elapsed = time.time() - t0

    # 清理临时分段文件
    for p in wav_paths:
        try:
            os.remove(p)
        except:
            pass

    print(f"[MODE]混读模式({len(segments)}段)")
    print(f"[AUDIO_FILE]{merged_path}")
    if not quiet:
        print(f"[完成] 混读合并耗时 {elapsed:.1f}s | 合并 {len(wav_paths)} 段")

    # 播放合并后的最终音频
    winsound.PlaySound(merged_path, winsound.SND_FILENAME)


if __name__ == "__main__":
    main()
